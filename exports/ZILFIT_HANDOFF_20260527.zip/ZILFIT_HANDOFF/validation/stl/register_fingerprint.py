#!/usr/bin/env python3
"""ZILFIT STL Fingerprint Registration CLI V1.

Register an STL file's SHA-256 hash in the fingerprint registry so the
release readiness gate's stl_fingerprint_lock check can PASS for that file.

Usage:
    # Register a known-good STL
    python3 validation/stl/register_fingerprint.py \\
        --stl tests/fixtures/stl/cube_watertight.stl

    # Register with explicit edition name and registry path
    python3 validation/stl/register_fingerprint.py \\
        --stl tests/fixtures/stl/cube_watertight.stl \\
        --edition test_cube \\
        --registry validation/stl/stl_fingerprint_registry.json

    # Verify a hash without registering (dry-run)
    python3 validation/stl/register_fingerprint.py \\
        --stl tests/fixtures/stl/cube_watertight.stl \\
        --check-only

Exit codes:
    0 — Hash computed and registered (or already registered in --check-only)
    1 — Error (file not found, unparseable registry, hash unavailable)

Forbidden:
    - No STL modification
    - No geometry repair
    - No network access
    - No production batch authorization
    - Only sample-only STL files may be registered
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

REGISTRAR_VERSION = "1.0"
VALIDATOR_VERSION = "1.0"
AUTHORITY_SOURCE = "sultan_engineering_gate_2"

SAMPLE_ONLY_NOTICE = (
    "Fingerprint registration is for SAMPLE-ONLY manufacturing. "
    "Registered STL files may not be used for production batches or "
    "multi-edition runs without additional governance approval."
)


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

DEFAULT_REGISTRY = (
    PROJECT_ROOT / "validation" / "stl" / "stl_fingerprint_registry.json"
)


# ---------------------------------------------------------------------------
# SHA-256 computation
# ---------------------------------------------------------------------------

def _file_sha256(path: str) -> str:
    """Compute full SHA-256 hex digest of a file (streaming, O(1) memory)."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Registry helpers
# ---------------------------------------------------------------------------

def _load_registry(registry_path: str) -> Dict[str, Any]:
    """Load and validate the fingerprint registry JSON.

    Returns the parsed registry dict.
    Raises on file-not-found, parse errors, or structural issues.
    """
    path = Path(registry_path)
    if not path.exists():
        raise FileNotFoundError(f"Fingerprint registry not found: {registry_path}")

    with open(path) as f:
        registry = json.load(f)

    if "registry" not in registry:
        raise ValueError(
            "Fingerprint registry missing required 'registry' key"
        )

    if not isinstance(registry["registry"], list):
        raise TypeError(
            f"Fingerprint registry 'registry' must be a list, "
            f"got {type(registry['registry']).__name__}"
        )

    return registry


def _save_registry(registry: Dict[str, Any], registry_path: str) -> None:
    """Write the updated registry back to disk with pretty-printing."""
    path = Path(registry_path)
    with open(path, "w") as f:
        json.dump(registry, f, indent=2)
        f.write("\n")


def _hash_already_registered(
    registry: Dict[str, Any],
    sha256: str,
) -> bool:
    """Check if a given SHA-256 hash is already in the registry."""
    for entry in registry.get("registry", []):
        if entry.get("sha256") == sha256:
            return True
    return False


def _find_registered_edition(
    registry: Dict[str, Any],
    sha256: str,
) -> str:
    """Find the edition name for a registered hash, or return empty string."""
    for entry in registry.get("registry", []):
        if entry.get("sha256") == sha256:
            return entry.get("edition", "")
    return ""


def _build_entry(
    stl_path: str,
    sha256: str,
    edition: str,
) -> Dict[str, Any]:
    """Build a single registry entry dict."""
    return {
        "edition": edition,
        "sha256": sha256,
        "validated_at": datetime.now(timezone.utc).isoformat(),
        "validator_version": VALIDATOR_VERSION,
    }


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------

def _display_registration(
    stl_path: str,
    sha256: str,
    edition: str,
    already_registered: bool,
    dry_run: bool,
) -> str:
    """Build a human-readable registration result message."""
    lines: List[str] = []
    border = "\u2500" * 60

    lines.append(border)
    lines.append("  ZILFIT STL FINGERPRINT REGISTRATION V1")
    lines.append(border)
    lines.append(f"  Authority:    {AUTHORITY_SOURCE}")
    lines.append(f"  STL:          {stl_path}")
    lines.append(f"  Edition:      {edition}")
    lines.append(f"  SHA-256:      {sha256}")

    if dry_run:
        if already_registered:
            lines.append("  Status:       ALREADY REGISTERED")
        else:
            lines.append("  Status:       NOT REGISTERED (dry-run, no changes made)")
    else:
        if already_registered:
            lines.append("  Status:       ALREADY REGISTERED (no changes needed)")
        else:
            lines.append("  Status:       REGISTERED")
            lines.append(f"  Timestamp:    {_build_entry(stl_path, sha256, edition)['validated_at']}")

    lines.append(border)
    lines.append(f"  {SAMPLE_ONLY_NOTICE}")
    lines.append(border)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Registration logic
# ---------------------------------------------------------------------------

def register_stl_hash(
    stl_path: str,
    edition: str = "test_fixture",
    registry_path: str = str(DEFAULT_REGISTRY),
    dry_run: bool = False,
) -> int:
    """Register an STL file's SHA-256 hash in the fingerprint registry.

    Args:
        stl_path: Path to the STL file to register.
        edition: Edition name for the entry (default: 'test_fixture').
        registry_path: Path to the fingerprint registry JSON.
        dry_run: If True, only check without modifying the registry.

    Returns:
        0 on success (or already registered), 1 on error.
    """
    # Validate STL exists
    stl = Path(stl_path)
    if not stl.exists():
        print(f"ERROR: STL file not found: {stl_path}", file=sys.stderr)
        return 1

    # Compute hash
    try:
        sha256 = _file_sha256(stl_path)
    except (OSError, PermissionError) as e:
        print(f"ERROR: Cannot compute hash for {stl_path}: {e}", file=sys.stderr)
        return 1

    # Load registry
    try:
        registry = _load_registry(registry_path)
    except (FileNotFoundError, json.JSONDecodeError, ValueError, TypeError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1

    # Check if already registered
    already = _hash_already_registered(registry, sha256)

    if already:
        edition_registered = _find_registered_edition(registry, sha256)
        print(_display_registration(stl_path, sha256, edition_registered, True, dry_run))
        return 0

    # Dry-run mode — don't modify
    if dry_run:
        print(_display_registration(stl_path, sha256, edition, False, True))
        return 0

    # Register
    entry = _build_entry(stl_path, sha256, edition)
    registry["registry"].append(entry)

    # Update registry-level metadata
    registry["status"] = "populated"

    # Save
    try:
        _save_registry(registry, registry_path)
    except (OSError, PermissionError) as e:
        print(f"ERROR: Cannot write registry: {e}", file=sys.stderr)
        return 1

    print(_display_registration(stl_path, sha256, edition, False, False))
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="ZILFIT STL Fingerprint Registration CLI V1",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Registers an STL file's SHA-256 hash in the fingerprint registry. "
            "After registration, the release readiness gate's "
            "stl_fingerprint_lock check can PASS for that file.\\n"
            "\\n"
            "Fingerprint registration is for SAMPLE-ONLY manufacturing only.\\n"
        ),
    )
    parser.add_argument(
        "--stl", required=True,
        help="Path to the STL file to register",
    )
    parser.add_argument(
        "--edition",
        default="test_fixture",
        help="Edition name for the registry entry (e.g., CALM, VITAL, test_cube)",
    )
    parser.add_argument(
        "--registry",
        default=str(DEFAULT_REGISTRY),
        help=f"Path to fingerprint registry JSON (default: {DEFAULT_REGISTRY})",
    )
    parser.add_argument(
        "--check-only",
        action="store_true",
        dest="dry_run",
        help="Only check if the hash is registered without modifying the registry",
    )
    args = parser.parse_args()

    return register_stl_hash(
        stl_path=args.stl,
        edition=args.edition,
        registry_path=args.registry,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    sys.exit(main())
