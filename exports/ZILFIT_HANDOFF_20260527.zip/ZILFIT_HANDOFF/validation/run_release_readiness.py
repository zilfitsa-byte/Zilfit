#!/usr/bin/env python3
"""ZILFIT Manufacturing Release Readiness Gate V1.

Aggregates all pre-print validation into a single PRINT_AUTHORIZED decision
for sample-only manufacturing.

Checks performed:
  1. manifest_authority       — MANIFEST_PREPRINT_V1.json exists, status=pre_print
  2. stl_fingerprint_lock     — STL hash is registered in fingerprint registry
  3. validation_runner        — run_preprint.py exits 0, verdict PASS
  4. regression_baseline      — run_regression.py exits 0
  5. material_consistency     — density authority material == TPU_75A_80A
  6. wall_threshold_compliance — Gate 1B status == PASS
  7. density_cap_compliance   — Gate 1C status == PASS
  8. print_spec_authority     — print spec exists, hash matches, fields present
  9. founder_signoff          — --founder-signoff == APPROVED

PRINT_AUTHORIZED = True only if ALL checks pass.

Usage:
    python validation/run_release_readiness.py \\
        --stl tests/fixtures/stl/cube_watertight.stl \\
        --density tests/fixtures/density/pass_nominal.json

    python validation/run_release_readiness.py \\
        --stl tests/fixtures/stl/cube_watertight.stl \\
        --density tests/fixtures/density/pass_nominal.json \\
        --founder-signoff APPROVED

Exit codes:
    0 — PRINT_AUTHORIZED (all checks pass)
    1 — BLOCKED (one or more checks fail)

Forbidden:
    - Modification of any existing validation gate, runner, regression, fixture,
      manifest, registry, or runtime module.
    - subprocess shell=True
    - Network access
    - Production batch authorization
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DEFAULT_MANIFEST = PROJECT_ROOT / "manufacturing" / "MANIFEST_PREPRINT_V1.json"
DEFAULT_REGISTRY = PROJECT_ROOT / "validation" / "stl" / "stl_fingerprint_registry.json"
DEFAULT_PRINT_SPEC = PROJECT_ROOT / "manufacturing" / "print_specs" / "TPU_75A_80A_MJF_SAMPLE_V1.json"
RUNNER = PROJECT_ROOT / "validation" / "run_preprint.py"
REGRESSION = PROJECT_ROOT / "validation" / "run_regression.py"

REQUIRED_MATERIAL = "TPU_75A_80A"
AUTHORITY_SOURCE = "sultan_engineering_gate_2"

COUPON_REMINDER = (
    "PRINT_AUTHORIZED decisions under this gate are for SAMPLE-ONLY manufacturing. "
    "No production batch, multi-edition run, or full-sole print is authorized until "
    "coupon gates 3\u20135 (CT-01 through CT-06) pass and Sultan gives explicit "
    "production authorization. See docs/COUPON_TEST_READINESS_PLAN_V1.md."
)

FOUNDER_SIGNED_NOTE = (
    "PRINT_AUTHORIZED=false. Founder approval required before any print proceeds."
)


# ---------------------------------------------------------------------------
# Check result type
# ---------------------------------------------------------------------------

class CheckResult:
    """Result of a single readiness check."""

    def __init__(self, check: str, status: str, detail: str):
        self.check = check
        self.status = status
        self.detail = detail

    def to_dict(self) -> Dict[str, str]:
        return {"check": self.check, "status": self.status, "detail": self.detail}

    @property
    def passed(self) -> bool:
        return self.status == "PASS"


# ---------------------------------------------------------------------------
# Helper: sha256 of a file
# ---------------------------------------------------------------------------

def _file_sha256(path: str) -> str:
    """Compute full SHA-256 hex digest of a file."""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return "(unavailable)"


# ---------------------------------------------------------------------------
# Helper: run subprocess (shell=False)
# ---------------------------------------------------------------------------

def _run_subprocess(cmd: List[str], timeout: int = 120) -> Tuple[int, str]:
    """Run a command via subprocess with shell=False.

    Returns (exit_code, stdout).
    """
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        cwd=str(PROJECT_ROOT),
        timeout=timeout,
    )
    return result.returncode, result.stdout


# ---------------------------------------------------------------------------
# Check implementations
# ---------------------------------------------------------------------------

def _check_manifest_authority(manifest_path: str) -> CheckResult:
    """Verify the manifest exists and has status='pre_print'."""
    path = Path(manifest_path)
    if not path.exists():
        return CheckResult(
            "manifest_authority", "FAIL",
            f"Manifest file not found: {manifest_path}",
        )

    try:
        with open(path) as f:
            manifest = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        return CheckResult(
            "manifest_authority", "FAIL",
            f"Manifest cannot be parsed: {e}",
        )

    status = manifest.get("status", "")
    if status != "pre_print":
        return CheckResult(
            "manifest_authority", "FAIL",
            f"Manifest status is '{status}', expected 'pre_print'",
        )

    print_auth = manifest.get("print_authorized", None)
    gate_count = len(manifest.get("preprint_gates", {}))

    return CheckResult(
        "manifest_authority", "PASS",
        f"MANIFEST_PREPRINT_V1.json exists, status='{status}', "
        f"print_authorized={print_auth}, {gate_count} preprint gates defined",
    )


def _check_stl_fingerprint_lock(
    stl_path: str,
    registry_path: str,
) -> CheckResult:
    """Verify the STL hash is registered in the fingerprint registry."""
    # Compute STL hash
    stl_hash = _file_sha256(stl_path)

    if stl_hash == "(unavailable)":
        return CheckResult(
            "stl_fingerprint_lock", "FAIL",
            f"Cannot compute hash for STL: {stl_path}",
        )

    # Read registry
    reg_path = Path(registry_path)
    if not reg_path.exists():
        return CheckResult(
            "stl_fingerprint_lock", "FAIL",
            f"Fingerprint registry not found: {registry_path}",
        )

    try:
        with open(reg_path) as f:
            registry = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        return CheckResult(
            "stl_fingerprint_lock", "FAIL",
            f"Fingerprint registry cannot be parsed: {e}",
        )

    registered_entries = registry.get("registry", [])
    if not registered_entries:
        return CheckResult(
            "stl_fingerprint_lock", "FAIL",
            f"STL hash computed: {stl_hash[:16]}..., but registry is empty \u2014 "
            f"no fingerprint registered for any edition",
        )

    # Look for a matching hash
    for entry in registered_entries:
        if entry.get("sha256") == stl_hash:
            edition = entry.get("edition", "unknown")
            validated_at = entry.get("validated_at", "unknown")
            return CheckResult(
                "stl_fingerprint_lock", "PASS",
                f"STL hash {stl_hash[:16]}... matches registered entry "
                f"for edition '{edition}' (validated {validated_at})",
            )

    return CheckResult(
        "stl_fingerprint_lock", "FAIL",
        f"STL hash {stl_hash[:16]}... not found in registry "
        f"({len(registered_entries)} entries checked)",
    )


def _check_validation_runner(
    stl_path: str, density_path: str,
) -> Tuple[CheckResult, Optional[Dict[str, Any]]]:
    """Run the unified pre-print runner and verify PASS verdict.

    Returns (check_result, runner_json) where runner_json is the parsed
    JSON output (or None if unavailable) for downstream gate extraction.
    """
    cmd = [sys.executable, str(RUNNER), "--json",
           "--stl", stl_path, "--density", density_path]

    runner_json: Optional[Dict[str, Any]] = None

    try:
        exit_code, stdout = _run_subprocess(cmd)
    except subprocess.TimeoutExpired:
        return (
            CheckResult(
                "validation_runner", "FAIL",
                "run_preprint.py timed out (120s)",
            ),
            None,
        )
    except OSError as e:
        return (
            CheckResult(
                "validation_runner", "FAIL",
                f"run_preprint.py failed to execute: {e}",
            ),
            None,
        )

    # Always parse JSON for downstream checks (even if runner failed)
    json_start = stdout.find("{")
    if json_start != -1:
        try:
            runner_json = json.loads(stdout[json_start:])
        except json.JSONDecodeError:
            pass

    verdict = "?"
    if runner_json is not None:
        verdict = runner_json.get("verdict", "?")

    gate_statuses = {}
    if runner_json is not None:
        gate_statuses = {g.get("gate", "?"): g.get("status", "?")
                         for g in runner_json.get("gates", [])}
    status_summary = ", ".join(f"{k}={v}" for k, v in gate_statuses.items())

    if exit_code != 0 or verdict != "PASS":
        return (
            CheckResult(
                "validation_runner", "FAIL",
                f"run_preprint.py exit {exit_code}, verdict={verdict} "
                f"({status_summary}) \u2014 expected exit 0, verdict PASS",
            ),
            runner_json,
        )

    return (
        CheckResult(
            "validation_runner", "PASS",
            f"run_preprint.py exit 0, verdict PASS ({status_summary})",
        ),
        runner_json,
    )


def _check_regression_baseline() -> CheckResult:
    """Run the regression harness and verify exit 0."""
    cmd = [sys.executable, str(REGRESSION)]

    try:
        exit_code, stdout = _run_subprocess(cmd, timeout=180)
    except subprocess.TimeoutExpired:
        return CheckResult(
            "regression_baseline", "FAIL",
            "run_regression.py timed out (180s)",
        )
    except OSError as e:
        return CheckResult(
            "regression_baseline", "FAIL",
            f"run_regression.py failed to execute: {e}",
        )

    if exit_code != 0:
        return CheckResult(
            "regression_baseline", "FAIL",
            f"run_regression.py exit {exit_code} \u2014 expected 0",
        )

    # Extract pass count from output
    pass_line = ""
    for line in stdout.splitlines():
        if "/" in line and "cases passed" in line:
            pass_line = line.strip()
            break

    return CheckResult(
        "regression_baseline", "PASS",
        f"run_regression.py exit 0 ({pass_line})",
    )


def _extract_gate_status(
    runner_json: Optional[Dict[str, Any]],
    gate_name: str,
) -> Optional[str]:
    """Extract a specific gate's status from the runner JSON output."""
    if runner_json is None:
        return None
    for gate in runner_json.get("gates", []):
        if gate.get("gate") == gate_name:
            return gate.get("status")
    return None


def _check_material_consistency(
    density_path: str,
) -> CheckResult:
    """Verify the density authority declares TPU_75A_80A material."""
    try:
        with open(density_path) as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        return CheckResult(
            "material_consistency", "FAIL",
            f"Density authority cannot be parsed: {e}",
        )

    material = data.get("material", "")
    if material != REQUIRED_MATERIAL:
        return CheckResult(
            "material_consistency", "FAIL",
            f"Density authority material='{material}' != "
            f"REQUIRED_MATERIAL='{REQUIRED_MATERIAL}'. "
            f"Material change invalidates existing simulation evidence. "
            f"Sultan must approve a separate material qualification gate "
            f"before print authorization.",
        )

    return CheckResult(
        "material_consistency", "PASS",
        f"Density authority material='{material}' matches "
        f"REQUIRED_MATERIAL='{REQUIRED_MATERIAL}'",
    )


def _check_wall_threshold_compliance(
    runner_json: Optional[Dict[str, Any]],
) -> CheckResult:
    """Verify Gate 1B (wall thickness) reports PASS."""
    status = _extract_gate_status(runner_json, "wall_thickness_validation")
    if status is None:
        return CheckResult(
            "wall_threshold_compliance", "NOT_CHECKED",
            "Gate 1B status not available (STL may not have been provided)",
        )

    if status != "PASS":
        return CheckResult(
            "wall_threshold_compliance", "FAIL",
            f"Gate 1B status={status} \u2014 expected PASS "
            f"(min_wall_mm must be >= 0.8 mm)",
        )

    return CheckResult(
        "wall_threshold_compliance", "PASS",
        f"Gate 1B status=PASS (min_wall_mm >= MIN_WALL_MM=0.8 mm)",
    )


def _check_density_cap_compliance(
    runner_json: Optional[Dict[str, Any]],
) -> CheckResult:
    """Verify Gate 1C (density jump) reports PASS."""
    status = _extract_gate_status(runner_json, "density_jump_validation")
    if status is None:
        return CheckResult(
            "density_cap_compliance", "NOT_CHECKED",
            "Gate 1C status not available (density authority may not have been provided)",
        )

    if status != "PASS":
        return CheckResult(
            "density_cap_compliance", "FAIL",
            f"Gate 1C status={status} \u2014 expected PASS "
            f"(max adjacent density delta must be <= 0.15)",
        )

    return CheckResult(
        "density_cap_compliance", "PASS",
        f"Gate 1C status=PASS (max adjacent delta <= MAX_DELTA=0.15)",
    )


def _check_print_spec_authority(
    print_spec_path: Optional[str],
) -> CheckResult:
    """Verify the print spec exists, its hash matches, and required fields are present."""
    if not print_spec_path:
        return CheckResult(
            "print_spec_authority", "FAIL",
            "No print spec provided (--print-spec required). "
            "A print specification must be supplied before sample manufacturing can proceed.",
        )

    spec_file = Path(print_spec_path)
    if not spec_file.exists():
        return CheckResult(
            "print_spec_authority", "FAIL",
            f"Print spec file not found: {print_spec_path}",
        )

    try:
        with open(spec_file) as f:
            spec = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        return CheckResult(
            "print_spec_authority", "FAIL",
            f"Print spec cannot be parsed: {e}",
        )

    # Verify spec_hash: compute hash over all fields EXCEPT spec_hash
    declared_hash = spec.get("spec_hash", "")
    if not declared_hash:
        return CheckResult(
            "print_spec_authority", "FAIL",
            f"Print spec is missing 'spec_hash' field",
        )

    # Compute hash over canonical JSON (sorted keys, no whitespace, excluding spec_hash)
    spec_copy = dict(spec)
    spec_copy.pop("spec_hash", None)
    canonical = json.dumps(spec_copy, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    computed_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    if computed_hash != declared_hash:
        return CheckResult(
            "print_spec_authority", "FAIL",
            f"Print spec hash mismatch: declared={declared_hash[:16]}..., "
            f"computed={computed_hash[:16]}... "
            f"\u2014 spec has been modified after signing",
        )

    # Verify required fields exist
    required_fields = [
        "spec_version", "spec_name", "material_family",
        "layer_height_mm", "infill_pattern", "infill_percent",
        "sample_only_restriction", "not_for_batch_production",
    ]
    missing = [f for f in required_fields if f not in spec]
    if missing:
        return CheckResult(
            "print_spec_authority", "FAIL",
            f"Print spec missing required field(s): {', '.join(missing)}",
        )

    # Verify sample-only fields are true
    if spec.get("sample_only_restriction") is not True:
        return CheckResult(
            "print_spec_authority", "FAIL",
            "Print spec sample_only_restriction must be True",
        )

    if spec.get("not_for_batch_production") is not True:
        return CheckResult(
            "print_spec_authority", "FAIL",
            "Print spec not_for_batch_production must be True",
        )

    spec_name = spec.get("spec_name", "unknown")
    material = spec.get("material_family", "unknown")
    return CheckResult(
        "print_spec_authority", "PASS",
        f"Print spec '{spec_name}' (v{spec.get('spec_version', '?')}) "
        f"exists, hash matches, material={material}, "
        f"sample_only={spec.get('sample_only_restriction')}",
    )


def _check_founder_signoff(founder_signoff: str) -> CheckResult:
    """Verify founder sign-off is APPROVED."""
    if founder_signoff == "APPROVED":
        return CheckResult(
            "founder_signoff", "PASS",
            "Founder sign-off status: APPROVED",
        )

    return CheckResult(
        "founder_signoff", "FAIL",
        f"Founder sign-off status: {founder_signoff} "
        f"\u2014 expected APPROVED. "
        f"{FOUNDER_SIGNED_NOTE}",
    )


# ---------------------------------------------------------------------------
# Human-readable report
# ---------------------------------------------------------------------------

def _build_report(
    checks: List[CheckResult],
    stl_path: str,
    density_path: str,
    print_spec_path: Optional[str],
    print_authorized: bool,
) -> str:
    """Build a human-readable release readiness report."""
    lines: List[str] = []
    border = "\u2500" * 60

    print_spec_label = print_spec_path if print_spec_path else "(not provided)"

    verdict_line = "PRINT AUTHORIZED" if print_authorized else "BLOCKED"
    verdict_icon = "\u2705" if print_authorized else "\u274c"

    lines.append(border)
    lines.append(f"  ZILFIT RELEASE READINESS GATE V1 \u2014 {verdict_icon} {verdict_line}")
    lines.append(border)
    lines.append(f"  Authority:    {AUTHORITY_SOURCE}")
    lines.append(f"  STL:          {stl_path}")
    lines.append(f"  Density:      {density_path}")
    lines.append(f"  Print Spec:   {print_spec_label}")
    lines.append(f"  Sample-only:  true")
    lines.append(border)

    # Per-check results
    for c in checks:
        icon = "\u2705" if c.passed else ("\u26a0\ufe0f" if c.status == "NOT_CHECKED" else "\u274c")
        lines.append(f"  {icon}  {c.check}")
        lines.append(f"       Status: {c.status}")
        lines.append(f"       {c.detail}")
        lines.append("")

    lines.append(border)
    if print_authorized:
        lines.append("  \u2705  PRINT AUTHORIZED")
    else:
        lines.append("  \u274c  PRINT AUTHORIZATION BLOCKED")
        reasons = [c.detail for c in checks if not c.passed]
        if reasons:
            lines.append("")
            for r in reasons:
                lines.append(f"       \u2022 {r}")

    lines.append(border)
    lines.append(f"  {COUPON_REMINDER}")
    lines.append(border)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main gate logic
# ---------------------------------------------------------------------------

def run_release_readiness(
    stl_path: str,
    density_path: str,
    manifest_path: str = str(DEFAULT_MANIFEST),
    registry_path: str = str(DEFAULT_REGISTRY),
    print_spec_path: Optional[str] = str(DEFAULT_PRINT_SPEC),
    founder_signoff: str = "PENDING",
) -> Tuple[bool, List[CheckResult]]:
    """Run all release readiness checks.

    Args:
        stl_path: Path to STL file.
        density_path: Path to density authority JSON.
        manifest_path: Path to manufacturing manifest JSON.
        registry_path: Path to fingerprint registry JSON.
        print_spec_path: Path to print specification JSON (None to skip spec check).
        founder_signoff: "PENDING", "APPROVED", or "DENIED".

    Returns (print_authorized, check_results).
    """
    checks: List[CheckResult] = []

    # Check 1: manifest authority
    checks.append(_check_manifest_authority(manifest_path))

    # Check 2: STL fingerprint lock
    checks.append(_check_stl_fingerprint_lock(stl_path, registry_path))

    # Check 3: validation runner — returns runner_json for downstream checks
    vc, runner_json = _check_validation_runner(stl_path, density_path)
    checks.append(vc)

    # Check 4: regression baseline
    checks.append(_check_regression_baseline())

    # Check 5: material consistency
    checks.append(_check_material_consistency(density_path))

    # Check 6: wall threshold compliance
    checks.append(_check_wall_threshold_compliance(runner_json))

    # Check 7: density cap compliance
    checks.append(_check_density_cap_compliance(runner_json))

    # Check 8: print spec authority
    checks.append(_check_print_spec_authority(print_spec_path))

    # Check 9: founder sign-off
    checks.append(_check_founder_signoff(founder_signoff))

    # Final decision
    print_authorized = all(c.passed for c in checks)

    return print_authorized, checks


# ---------------------------------------------------------------------------
# JSON output builder
# ---------------------------------------------------------------------------

def _build_json_output(
    print_authorized: bool,
    checks: List[CheckResult],
    stl_path: str,
    density_path: str,
    manifest_path: str,
    registry_path: str,
    print_spec_path: Optional[str],
    founder_signoff: str,
) -> Dict[str, Any]:
    """Build machine-readable JSON output."""
    reasons_blocked = [
        c.detail for c in checks if not c.passed
    ]

    return {
        "gate": "release_readiness",
        "gate_version": "1.0",
        "authority_source": AUTHORITY_SOURCE,
        "print_authorized": print_authorized,
        "sample_only_scope": True,
        "coupon_test_reminder": COUPON_REMINDER,
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "inputs": {
            "stl": stl_path,
            "density": density_path,
            "manifest": manifest_path,
            "fingerprint_registry": registry_path,
            "print_spec": print_spec_path,
        },
        "checks": [c.to_dict() for c in checks],
        "reasons_blocked": reasons_blocked,
        "founder_signoff": {
            "required": True,
            "status": founder_signoff,
            "note": FOUNDER_SIGNED_NOTE,
        },
        "boundary": {
            "sample_only": True,
            "no_production_batch_authorization": True,
            "no_medical_claims": True,
            "engineering_only": True,
        },
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    """CLI entry point. Returns 0 on PRINT AUTHORIZED, 1 on BLOCKED."""
    parser = argparse.ArgumentParser(
        description="ZILFIT Manufacturing Release Readiness Gate V1",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "All checks must pass before PRINT_AUTHORIZED=True. "
            "Sample-only scope applies. "
            "No production batch authorization.\n"
        ),
    )
    parser.add_argument(
        "--stl", required=True,
        help="Path to the STL file for print",
    )
    parser.add_argument(
        "--density", required=True,
        help="Path to the density authority JSON file",
    )
    parser.add_argument(
        "--manifest",
        default=str(DEFAULT_MANIFEST),
        help=f"Path to manifest JSON (default: {DEFAULT_MANIFEST})",
    )
    parser.add_argument(
        "--fingerprint-registry",
        default=str(DEFAULT_REGISTRY),
        help=f"Path to fingerprint registry JSON (default: {DEFAULT_REGISTRY})",
    )
    parser.add_argument(
        "--founder-signoff",
        default="PENDING",
        choices=("PENDING", "APPROVED", "DENIED"),
        help="Founder sign-off status (default: PENDING)",
    )
    parser.add_argument(
        "--print-spec",
        default=str(DEFAULT_PRINT_SPEC),
        help=f"Path to print specification JSON (default: {DEFAULT_PRINT_SPEC})",
    )
    parser.add_argument(
        "--no-print-spec",
        action="store_true",
        help="Skip print spec check (for testing/development only). Overrides --print-spec.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Append machine-readable JSON output after the human report",
    )
    args = parser.parse_args()

    # Resolve print spec path (--no-print-spec overrides --print-spec)
    print_spec_path: Optional[str] = None
    if args.no_print_spec:
        print_spec_path = None
    else:
        print_spec_path = args.print_spec

    # Validate paths exist
    path_checks = [
        ("--stl", args.stl),
        ("--density", args.density),
        ("--manifest", args.manifest),
    ]
    if print_spec_path:
        path_checks.append(("--print-spec", print_spec_path))

    for arg_name, arg_path in path_checks:
        if not Path(arg_path).exists():
            print(f"ERROR: {arg_name} file not found: {arg_path}", file=sys.stderr)
            return 1

    # Run checks
    print_authorized, checks = run_release_readiness(
        stl_path=args.stl,
        density_path=args.density,
        manifest_path=args.manifest,
        registry_path=args.fingerprint_registry,
        print_spec_path=print_spec_path,
        founder_signoff=args.founder_signoff,
    )

    # Build and print report
    report = _build_report(checks, args.stl, args.density, print_spec_path, print_authorized)
    print(report)

    # Append JSON if requested
    if args.json:
        json_output = _build_json_output(
            print_authorized, checks,
            args.stl, args.density, args.manifest, args.fingerprint_registry,
            print_spec_path, args.founder_signoff,
        )
        print()
        print(json.dumps(json_output, indent=2))

    return 0 if print_authorized else 1


if __name__ == "__main__":
    sys.exit(main())
