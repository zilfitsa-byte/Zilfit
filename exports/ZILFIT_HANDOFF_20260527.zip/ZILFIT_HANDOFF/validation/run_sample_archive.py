#!/usr/bin/env python3
"""ZILFIT Manufacturing Sample Archive V1.

Creates an immutable traceability record for every sample manufacturing
attempt. Each record captures the release readiness verdict, artifact
fingerprints, printer metadata, and optional physical measurement fields.

Records are written as one JSON file per sample under
manufacturing/archive/{sample_id}.json and are never overwritten.

Usage:
    # Create archive record from a release readiness JSON output
    python3 validation/run_sample_archive.py \\
        --release-json /tmp/release_output.json \\
        --sample-id ZILFIT-CALM-0001 \\
        --edition CALM \\
        --printer-model "HP MJF 580" \\
        --material TPU_75A_80A \\
        --material-batch-id "TPU-2026-05-B012" \\
        --operator "Sultan" \\
        --reviewer "Sultan"

    # With optional measurement fields
    python3 validation/run_sample_archive.py \\
        --release-json /tmp/release_output.json \\
        --sample-id ZILFIT-CALM-0002 \\
        --edition CALM \\
        --printer-model "HP MJF 580" \\
        --material TPU_75A_80A \\
        --material-batch-id "TPU-2026-05-B012" \\
        --operator "Sultan" \\
        --reviewer "Sultan" \\
        --measured-weight-g 42.5 \\
        --measured-dimensions-mm "250.2x85.1x12.8" \\
        --visual-defects "none" \\
        --dimensional-pass true \\
        --comfort-review-status "PASS" \\
        --coupon-test-status "PENDING" \\
        --final-review-status "PENDING" \\
        --review-notes "First sample. Dimensional check passed. Waiting on coupon tests."

Exit codes:
    0 — Archive record created (SAMPLE_RECORD_CREATED)
    1 — Blocked, duplicate, or error (BLOCKED_SAMPLE_RECORD or error)

Forbidden:
    - No STL modification
    - No print spec modification
    - No hash mutation
    - No production authorization
    - No batch production wording
    - No silent overwrite
    - No network
    - No subprocess shell=True
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent
ARCHIVE_DIR = PROJECT_ROOT / "manufacturing" / "archive"
ARCHIVE_VERSION = "1.0"
AUTHORITY_SOURCE = "sultan_engineering_gate_2"

SAMPLE_ONLY_NOTICE = (
    "This archive record is for SAMPLE-ONLY manufacturing. "
    "No production batch, multi-edition run, or full-sole print "
    "is authorized by the existence of this record."
)

# Fields that must be non-PENDING for final_review_status == "PASS"
REQUIRED_FOR_FINAL_PASS: set = {
    "measured_weight_g",
    "measured_dimensions_mm",
    "visual_defects",
    "dimensional_pass",
    "comfort_review_status",
    "coupon_test_status",
}


# ---------------------------------------------------------------------------
# SHA-256 helper
# ---------------------------------------------------------------------------

def _file_sha256(path: str) -> str:
    """Compute full SHA-256 hex digest of a file (streaming, O(1) memory)."""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except (OSError, PermissionError, FileNotFoundError):
        return "(unavailable)"


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

def _validate_measurements(
    measurements: Dict[str, Any],
    final_review_status: str,
) -> List[str]:
    """Validate measurement fields.

    Returns a list of error messages (empty if valid).
    """
    errors: List[str] = []

    if final_review_status == "PASS":
        for field in REQUIRED_FOR_FINAL_PASS:
            value = measurements.get(field)
            if value is None or value == "" or value == "PENDING":
                errors.append(
                    f"final_review_status is 'PASS' but '{field}' is "
                    f"missing or 'PENDING'. All measurement fields must "
                    f"be completed before final review can pass."
                )

    # Validate dimensional_pass if provided
    dp = measurements.get("dimensional_pass")
    if dp is not None and dp not in (True, False, "PENDING", ""):
        errors.append(
            f"dimensional_pass must be true, false, or 'PENDING', "
            f"got '{dp}'"
        )

    # Validate review statuses if provided
    for status_field in ("comfort_review_status", "coupon_test_status", "final_review_status"):
        val = measurements.get(status_field)
        if val and val not in ("PASS", "FAIL", "PENDING", ""):
            errors.append(
                f"{status_field} must be 'PASS', 'FAIL', or 'PENDING', "
                f"got '{val}'"
            )

    # Validate measured_weight_g if provided (allow "PENDING" sentinel)
    mw = measurements.get("measured_weight_g")
    if mw is not None and mw not in ("", "PENDING") and not isinstance(mw, (int, float)):
        errors.append(
            f"measured_weight_g must be a number or 'PENDING', "
            f"got '{type(mw).__name__}'"
        )

    return errors


def _validate_archive_record(
    record: Dict[str, Any],
) -> List[str]:
    """Validate the complete archive record before writing.

    Returns a list of error messages (empty if valid).
    """
    errors: List[str] = []

    # Required fields
    required = [
        "sample_id", "edition", "archive_version",
        "status", "created_at",
    ]
    for field in required:
        if field not in record or record[field] is None:
            errors.append(f"Archive record missing required field: '{field}'")

    # Release readiness fields
    rr_required = [
        "release_readiness_verdict", "print_authorized",
        "founder_signoff", "checked_at",
    ]
    for field in rr_required:
        if field not in record.get("release_readiness", {}):
            errors.append(f"Release readiness data missing required field: '{field}'")

    # Artifact paths
    artifacts_required = [
        "stl_path", "stl_sha256",
        "density_authority_path", "density_authority_sha256",
    ]
    for field in artifacts_required:
        if field not in record.get("artifacts", {}):
            errors.append(f"Artifact data missing required field: '{field}'")

    # Print metadata
    meta_required = [
        "printer_model", "material", "material_batch_id",
        "operator", "reviewer",
    ]
    for field in meta_required:
        if field not in record.get("print_metadata", {}):
            errors.append(f"Print metadata missing required field: '{field}'")

    return errors


# ---------------------------------------------------------------------------
# Archive record builder
# ---------------------------------------------------------------------------

def _build_archive_record(
    release_json: Dict[str, Any],
    sample_id: str,
    edition: str,
    printer_model: str,
    material: str,
    material_batch_id: str,
    operator: str,
    reviewer: str,
    measurements: Dict[str, Any],
    status: str,
) -> Dict[str, Any]:
    """Build a complete archive record dictionary.

    Args:
        release_json: Parsed release readiness JSON output.
        sample_id: Unique sample identifier.
        edition: ZILFIT edition name.
        printer_model: Printer model string.
        material: Material identifier.
        material_batch_id: Material batch/lot ID.
        operator: Operator name.
        reviewer: Reviewer name.
        measurements: Optional physical measurement fields.
        status: Archive record status.

    Returns:
        Complete archive record dictionary ready for serialization.
    """
    # Extract paths from release JSON inputs
    inputs = release_json.get("inputs", {})
    stl_path = inputs.get("stl", "")
    density_path = inputs.get("density", "")
    print_spec_path = inputs.get("print_spec", "")

    # Compute SHA-256 hashes of the referenced artifacts
    stl_sha256 = _file_sha256(stl_path) if stl_path else "(not provided)"
    density_sha256 = _file_sha256(density_path) if density_path else "(not provided)"
    print_spec_sha256 = _file_sha256(print_spec_path) if print_spec_path else "(not provided)"

    # Extract founder signoff status
    founder_signoff_data = release_json.get("founder_signoff", {})
    founder_signoff_status = founder_signoff_data.get("status", "unknown")

    # Get checked_at timestamp from release readiness
    checked_at = release_json.get("checked_at", "")

    now = datetime.now(timezone.utc)

    record: Dict[str, Any] = {
        "archive_type": "manufacturing_sample",
        "archive_version": ARCHIVE_VERSION,
        "authority_source": AUTHORITY_SOURCE,
        "status": status,
        "sample_id": sample_id,
        "edition": edition,
        "created_at": now.isoformat(),
        "sample_only_scope": True,
        "sample_only_notice": SAMPLE_ONLY_NOTICE,

        "release_readiness": {
            "release_json_source": release_json.get("gate", "unknown"),
            "gate_version": release_json.get("gate_version", ""),
            "print_authorized": release_json.get("print_authorized", False),
            "release_readiness_verdict": (
                "PASS" if release_json.get("print_authorized", False)
                else "FAIL"
            ),
            "founder_signoff": founder_signoff_status,
            "checked_at": checked_at,
            "reasons_blocked": release_json.get("reasons_blocked", []),
        },

        "artifacts": {
            "stl_path": stl_path,
            "stl_sha256": stl_sha256,
            "density_authority_path": density_path,
            "density_authority_sha256": density_sha256,
            "print_spec_path": print_spec_path,
            "print_spec_sha256": print_spec_sha256,
        },

        "print_metadata": {
            "printer_model": printer_model,
            "material": material,
            "material_batch_id": material_batch_id,
            "operator": operator,
            "reviewer": reviewer,
        },

        "schedule": {
            "print_started_at": measurements.get("print_started_at", "PENDING"),
            "print_completed_at": measurements.get("print_completed_at", "PENDING"),
        },

        "measurements": {
            "measured_weight_g": measurements.get("measured_weight_g", "PENDING"),
            "measured_dimensions_mm": measurements.get("measured_dimensions_mm", "PENDING"),
            "visual_defects": measurements.get("visual_defects", "PENDING"),
            "dimensional_pass": measurements.get("dimensional_pass", "PENDING"),
            "comfort_review_status": measurements.get("comfort_review_status", "PENDING"),
            "coupon_test_status": measurements.get("coupon_test_status", "PENDING"),
            "final_review_status": measurements.get("final_review_status", "PENDING"),
            "review_notes": measurements.get("review_notes", ""),
        },

        "boundary": {
            "sample_only": True,
            "no_production_batch_authorization": True,
            "no_medical_claims": True,
            "engineering_only": True,
        },
    }

    return record


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------

def _build_report(
    record: Dict[str, Any],
    archive_path: str,
) -> str:
    """Build a human-readable archive creation report."""
    lines: List[str] = []
    border = "\u2500" * 60

    status = record["status"]
    sample_id = record["sample_id"]
    edition = record["edition"]

    status_icon = "\u2705" if "CREATED" in status else "\u274c"
    verdict_line = "RECORD CREATED" if "CREATED" in status else "BLOCKED RECORD"

    lines.append(border)
    lines.append(f"  ZILFIT MANUFACTURING SAMPLE ARCHIVE V1 \u2014 {status_icon} {verdict_line}")
    lines.append(border)
    lines.append(f"  Authority:    {AUTHORITY_SOURCE}")
    lines.append(f"  Status:       {status}")
    lines.append(f"  Sample ID:    {sample_id}")
    lines.append(f"  Edition:      {edition}")
    lines.append(border)

    # Release readiness
    rr = record.get("release_readiness", {})
    lines.append(f"  Release Readiness:")
    lines.append(f"       Verdict:      {rr.get('release_readiness_verdict', '?')}")
    lines.append(f"       Authorized:   {rr.get('print_authorized', '?')}")
    lines.append(f"       Signoff:      {rr.get('founder_signoff', '?')}")
    lines.append(f"       Checked at:   {rr.get('checked_at', '?')}")

    # Artifacts
    arts = record.get("artifacts", {})
    lines.append(f"  Artifacts:")
    lines.append(f"       STL:          {arts.get('stl_sha256', '?')[:20]}...")
    lines.append(f"       Density:      {arts.get('density_authority_sha256', '?')[:20]}...")
    sha256 = arts.get("print_spec_sha256", "")
    if sha256:
        lines.append(f"       Print Spec:   {sha256[:20]}...")

    # Print metadata
    meta = record.get("print_metadata", {})
    lines.append(f"  Print:")
    lines.append(f"       Printer:      {meta.get('printer_model', '?')}")
    lines.append(f"       Material:     {meta.get('material', '?')} ({meta.get('material_batch_id', '?')})")
    lines.append(f"       Operator:     {meta.get('operator', '?')}")
    lines.append(f"       Reviewer:     {meta.get('reviewer', '?')}")

    # Measurements (only if not all PENDING)
    meas = record.get("measurements", {})
    has_measurements = any(
        v not in ("PENDING", "") for v in meas.values()
    )
    if has_measurements:
        lines.append(f"  Measurements:")
        if meas.get("measured_weight_g") not in ("PENDING", ""):
            lines.append(f"       Weight:       {meas['measured_weight_g']} g")
        if meas.get("measured_dimensions_mm") not in ("PENDING", ""):
            lines.append(f"       Dimensions:   {meas['measured_dimensions_mm']} mm")
        if meas.get("dimensional_pass") not in ("PENDING", ""):
            lines.append(f"       Dimensional:  {meas['dimensional_pass']}")
        if meas.get("comfort_review_status") not in ("PENDING", ""):
            lines.append(f"       Comfort:      {meas['comfort_review_status']}")
        if meas.get("coupon_test_status") not in ("PENDING", ""):
            lines.append(f"       Coupon Test:  {meas['coupon_test_status']}")
        if meas.get("final_review_status") not in ("PENDING", ""):
            lines.append(f"       Final Review: {meas['final_review_status']}")
        notes = meas.get("review_notes", "")
        if notes:
            lines.append(f"       Notes:        {notes[:80]}")

    lines.append(border)
    lines.append(f"  Archive file: {archive_path}")
    lines.append(border)
    lines.append(f"  {SAMPLE_ONLY_NOTICE}")
    lines.append(border)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main archive logic
# ---------------------------------------------------------------------------

def create_archive_record(
    release_json_path: str,
    sample_id: str,
    edition: str,
    printer_model: str,
    material: str,
    material_batch_id: str,
    operator: str,
    reviewer: str,
    measurements: Dict[str, Any],
    output_json: bool = False,
) -> int:
    """Create an immutable archive record for a sample manufacturing attempt.

    Args:
        release_json_path: Path to the release readiness JSON output file.
        sample_id: Unique sample identifier.
        edition: ZILFIT edition name.
        printer_model: Printer model string.
        material: Material identifier.
        material_batch_id: Material batch/lot ID.
        operator: Operator name.
        reviewer: Reviewer name.
        measurements: Optional physical measurement fields dict.
        output_json: If True, print machine-readable JSON result.

    Returns:
        0 on success, 1 on error.
    """
    # Step 1: Validate release JSON file exists and is parseable
    release_path = Path(release_json_path)
    if not release_path.exists():
        print(f"ERROR: Release readiness JSON not found: {release_json_path}",
              file=sys.stderr)
        return 1

    try:
        with open(release_path) as f:
            content = f.read()
            # Find the first JSON object in the file (may be preceded by
            # human-readable report)
            json_start = content.find("{")
            if json_start == -1:
                print(
                    f"ERROR: Cannot parse release readiness JSON: "
                    f"no JSON object found in {release_json_path}",
                    file=sys.stderr,
                )
                return 1
            release_json = json.loads(content[json_start:])
    except (json.JSONDecodeError, OSError) as e:
        print(f"ERROR: Cannot parse release readiness JSON: {e}",
              file=sys.stderr)
        return 1

    # Step 2: Extract and validate release readiness verdict
    print_authorized = release_json.get("print_authorized", False)
    reasons_blocked = release_json.get("reasons_blocked", [])

    if not isinstance(print_authorized, bool):
        print(
            f"ERROR: Release readiness 'print_authorized' must be a boolean, "
            f"got '{type(print_authorized).__name__}'",
            file=sys.stderr,
        )
        return 1

    # Step 3: Determine archive status
    if print_authorized:
        archive_status = "SAMPLE_RECORD_CREATED"
        exit_code = 0
    else:
        archive_status = "BLOCKED_SAMPLE_RECORD"
        exit_code = 1

    # Step 4: Build archive record
    record = _build_archive_record(
        release_json=release_json,
        sample_id=sample_id,
        edition=edition,
        printer_model=printer_model,
        material=material,
        material_batch_id=material_batch_id,
        operator=operator,
        reviewer=reviewer,
        measurements=measurements,
        status=archive_status,
    )

    # Step 5: Validate measurements
    meas_errors = _validate_measurements(measurements,
                                          record.get("measurements", {}).get("final_review_status", "PENDING"))
    if meas_errors:
        for err in meas_errors:
            print(f"ERROR: {err}", file=sys.stderr)
        return 1

    # Step 6: Validate complete record
    rec_errors = _validate_archive_record(record)
    if rec_errors:
        for err in rec_errors:
            print(f"ERROR: {err}", file=sys.stderr)
        return 1

    # Step 7: Check for duplicate sample_id
    archive_file = ARCHIVE_DIR / f"{sample_id}.json"
    if archive_file.exists():
        print(
            f"ERROR: Duplicate sample_id '{sample_id}' \u2014 "
            f"archive file already exists: {archive_file}",
            file=sys.stderr,
        )
        return 1

    # Step 8: Ensure archive directory exists
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)

    # Step 9: Write archive record (immutable — never overwrite)
    try:
        with open(archive_file, "x") as f:
            json.dump(record, f, indent=2)
            f.write("\n")
    except FileExistsError:
        print(
            f"ERROR: Race condition \u2014 archive file was created "
            f"concurrently: {archive_file}",
            file=sys.stderr,
        )
        return 1
    except (OSError, PermissionError) as e:
        print(f"ERROR: Cannot write archive file: {e}", file=sys.stderr)
        return 1

    # Step 10: Print report
    report = _build_report(record, str(archive_file))
    print(report)

    # Step 11: Print JSON output if requested
    if output_json:
        print()
        result = {
            "tool": "run_sample_archive",
            "tool_version": ARCHIVE_VERSION,
            "status": archive_status,
            "sample_id": sample_id,
            "archive_file": str(archive_file),
            "created_at": record["created_at"],
            "sample_only_scope": True,
        }
        print(json.dumps(result, indent=2))

    return exit_code


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> int:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="ZILFIT Manufacturing Sample Archive V1",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Creates an immutable traceability record for every sample "
            "manufacturing attempt. Records are archived under "
            "manufacturing/archive/{sample_id}.json and are never "
            "overwritten.\n"
        ),
    )

    # Required arguments
    parser.add_argument(
        "--release-json", required=True,
        help="Path to the release readiness JSON output file "
             "(from run_release_readiness.py --json)",
    )
    parser.add_argument(
        "--sample-id", required=True,
        help="Unique sample identifier (e.g., ZILFIT-CALM-0001)",
    )
    parser.add_argument(
        "--edition", required=True,
        help="ZILFIT edition name (e.g., CALM, VITAL, BALANCE)",
    )

    # Print metadata
    parser.add_argument(
        "--printer-model", required=True,
        help="Printer model (e.g., HP MJF 580)",
    )
    parser.add_argument(
        "--material", required=True,
        help="Material identifier (e.g., TPU_75A_80A)",
    )
    parser.add_argument(
        "--material-batch-id", required=True,
        help="Material batch or lot ID",
    )
    parser.add_argument(
        "--operator", required=True,
        help="Operator name",
    )
    parser.add_argument(
        "--reviewer", required=True,
        help="Reviewer name",
    )

    # Optional schedule fields
    parser.add_argument(
        "--print-started-at",
        help="ISO-8601 timestamp when print started (optional)",
    )
    parser.add_argument(
        "--print-completed-at",
        help="ISO-8601 timestamp when print completed (optional)",
    )

    # Optional physical measurement fields
    parser.add_argument(
        "--measured-weight-g",
        type=float,
        help="Measured weight in grams (optional)",
    )
    parser.add_argument(
        "--measured-dimensions-mm",
        help="Measured dimensions as string, e.g. '250.2x85.1x12.8' (optional)",
    )
    parser.add_argument(
        "--visual-defects",
        help="Visual defect description or 'none' (optional)",
    )
    parser.add_argument(
        "--dimensional-pass",
        choices=("true", "false"),
        help="Dimensional inspection pass/fail (optional)",
    )
    parser.add_argument(
        "--comfort-review-status",
        choices=("PASS", "FAIL", "PENDING"),
        help="Comfort review status (optional)",
    )
    parser.add_argument(
        "--coupon-test-status",
        choices=("PASS", "FAIL", "PENDING"),
        help="Coupon test status (optional)",
    )
    parser.add_argument(
        "--final-review-status",
        choices=("PASS", "FAIL", "PENDING"),
        help="Final review status (optional)",
    )
    parser.add_argument(
        "--review-notes",
        help="Review notes (optional)",
    )

    # Output options
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print machine-readable JSON result after the human report",
    )

    args = parser.parse_args()

    # Convert dimensional-pass from string to bool if provided
    dimensional_pass: Any = "PENDING"
    if args.dimensional_pass == "true":
        dimensional_pass = True
    elif args.dimensional_pass == "false":
        dimensional_pass = False

    # Build measurements dict
    measurements: Dict[str, Any] = {
        "print_started_at": args.print_started_at or "PENDING",
        "print_completed_at": args.print_completed_at or "PENDING",
        "measured_weight_g": args.measured_weight_g if args.measured_weight_g is not None else "PENDING",
        "measured_dimensions_mm": args.measured_dimensions_mm or "PENDING",
        "visual_defects": args.visual_defects or "PENDING",
        "dimensional_pass": dimensional_pass,
        "comfort_review_status": args.comfort_review_status or "PENDING",
        "coupon_test_status": args.coupon_test_status or "PENDING",
        "final_review_status": args.final_review_status or "PENDING",
        "review_notes": args.review_notes or "",
    }

    return create_archive_record(
        release_json_path=args.release_json,
        sample_id=args.sample_id,
        edition=args.edition,
        printer_model=args.printer_model,
        material=args.material,
        material_batch_id=args.material_batch_id,
        operator=args.operator,
        reviewer=args.reviewer,
        measurements=measurements,
        output_json=args.json,
    )


if __name__ == "__main__":
    sys.exit(main())
