# ZILFIT STL Hash Lock V1

**Document type:** Engineering release authority
**Status:** Active
**Gate version:** 1.0
**Authority source:** `sultan_engineering_gate_2`
**Applies to:** Sample-only manufacturing — no production batch authorization
**Date:** 2026-05-26

---

## 1. Purpose

The STL Hash Lock prevents any STL file from proceeding to manufacturing
unless its SHA-256 hash is **registered** and **matches** the validated
artifact in the fingerprint registry.

This is a **prevention** gate, not a detection gate. Its role is to ensure
that the exact file submitted for gate validation is the same file that
would be sent to manufacturing. Any modification — re-export, vertex
rounding change, triangle reordering — changes the hash and blocks the print.

---

## 2. How It Works

### 2.1 Hash Computation

The hash is computed using **SHA-256** over the **full STL file contents**
(streaming, O(1) memory):

```python
import hashlib
h = hashlib.sha256()
with open("model.stl", "rb") as f:
    for chunk in iter(lambda: f.read(65536), b""):
        h.update(chunk)
return h.hexdigest()
```

This is a **file-level** hash, distinct from the canonical mesh fingerprint
computed by `runtime/zilfit_fingerprint_contract.py` (which operates on
extracted mesh data). The release gate uses file-level hashing because it
is the simplest deterministic check for "has this exact file been
registered?"

### 2.2 Registry Schema

The fingerprint registry at `validation/stl/stl_fingerprint_registry.json`
stores registered hashes as an array of entries:

| Field | Type | Description |
|-------|------|-------------|
| `edition` | string | Edition name (e.g., CALM, VITAL, test_cube) |
| `sha256` | string | 64-character lowercase hex SHA-256 digest |
| `validated_at` | string (ISO-8601) | Timestamp of fingerprint registration |
| `validator_version` | string (const: "1.0") | Version of the fingerprint contract |

The registry also has top-level metadata:

| Field | Description |
|-------|-------------|
| `$schema` | JSON Schema reference |
| `title` | "ZILFIT STL Fingerprint Registry" |
| `description` | Authority registry for locked STL fingerprints |
| `manifest_reference` | Link to MANIFEST_PREPRINT_V1.json |
| `gate` | "gate_0_stl_fingerprint" |
| `status` | "PENDING" or "populated" |
| `validator_version` | "1.0" |
| `registry` | Array of registered entries |

### 2.3 Registration CLI

A dedicated CLI tool registers STL hashes:

```bash
# Register a known-good STL
python3 validation/stl/register_fingerprint.py \
    --stl tests/fixtures/stl/cube_watertight.stl

# Register with explicit edition name
python3 validation/stl/register_fingerprint.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --edition test_cube

# Dry-run: check if hash is already registered without modifying
python3 validation/stl/register_fingerprint.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --check-only
```

### 2.4 Release Readiness Integration

The release readiness gate (`validation/run_release_readiness.py`) checks
the STL hash lock as check #2 (`stl_fingerprint_lock`):

```python
# Inside run_release_readiness():
checks.append(_check_stl_fingerprint_lock(stl_path, registry_path))
```

The check function:
1. Computes SHA-256 of the provided STL file
2. Reads the fingerprint registry
3. Searches for a matching hash in all registered entries
4. Returns PASS if a match is found, FAIL otherwise

---

## 3. Required Behaviors

| Scenario | Expected Result |
|----------|----------------|
| STL path provided, hash not registered | **BLOCKED** — FAIL with reason: "registry is empty" or "hash not found" |
| STL hash differs from all registry entries | **BLOCKED** — FAIL with reason: "hash not found in registry" |
| STL hash matches a registered entry | **PASS** — hash gate passes |
| STL file cannot be read | **BLOCKED** — FAIL with reason: "cannot compute hash" |
| Registry file missing or corrupt | **BLOCKED** — FAIL with reason: "registry not found" or "cannot be parsed" |

**Important:** `PRINT_AUTHORIZED` remains `false` unless **all** checks
(including manifest, validation runner, regression, material, wall
threshold, density cap, and founder sign-off) pass. The hash lock alone
is not sufficient for authorization.

---

## 4. Example Registration Workflow

```bash
# 1. Compute and check the hash (dry-run, no changes)
python3 validation/stl/register_fingerprint.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --check-only

# 2. Register the hash
python3 validation/stl/register_fingerprint.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --edition test_cube

# 3. Verify the hash lock now passes
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --json | python3 -c "import sys,json; d=json.load(sys.stdin); print('Print authorized:', d['print_authorized']); [print(f\"  {c['check']}: {c['status']}\") for c in d['checks']]"

# 4. Verify hash lock with a different STL (should fail)
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/nonmanifold_5edge.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --json | python3 -c "import sys,json; d=json.load(sys.stdin); print('stl_fingerprint_lock:', [c for c in d['checks'] if c['check']=='stl_fingerprint_lock'][0])"
```

---

## 5. Hash Mismatch Example

If an STL file is modified after registration — even by a single byte — its
hash changes and the lock check fails:

```bash
# Copy a registered STL and alter it
cp tests/fixtures/stl/cube_watertight.stl /tmp/altered.stl
python3 -c "
data = open('/tmp/altered.stl', 'rb').read()
data = data.replace(b'vertex 10', b'vertex 11')  # alter one vertex
open('/tmp/altered.stl', 'wb').write(data)
"

# Run release readiness — stl_fingerprint_lock should FAIL
python3 validation/run_release_readiness.py \
    --stl /tmp/altered.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --json | python3 -c "import sys,json; d=json.load(sys.stdin); print('stl_fingerprint_lock:', [c for c in d['checks'] if c['check']=='stl_fingerprint_lock'][0])"
```

Expected: `stl_fingerprint_lock: FAIL` with "hash not found in registry".

---

## 6. Boundaries

| Topic | Status |
|-------|--------|
| Production batch authorization | **Explicitly excluded** — sample-only scope |
| Multi-edition validation | **Excluded** — single-edition pilot required first |
| STL modification or repair | **Excluded** — hash lock is read-only |
| Geometry mutation | **Excluded** — no geometry is read or processed |
| Network access | **Excluded** — all operations are local |
| Silent pass | **Excluded** — every check generates visible output |
| Medical, therapeutic, or clinical claims | **Excluded** — engineering-only |

---

## 7. Verification Commands

```bash
# Syntax checks
python3 -m py_compile validation/stl/register_fingerprint.py

# Registration — dry-run (no changes)
python3 validation/stl/register_fingerprint.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --check-only

# Registration — live
python3 validation/stl/register_fingerprint.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --edition test_cube

# Release readiness — registered STL (hash PASS, but still BLOCKED overall)
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --founder-signoff APPROVED

# Release readiness — unregistered STL (hash FAIL)
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/nonmanifold_5edge.stl \
    --density tests/fixtures/density/pass_nominal.json

# Hash mismatch (altered STL)
cp tests/fixtures/stl/cube_watertight.stl /tmp/altered.stl
python3 -c "
data = open('/tmp/altered.stl', 'rb').read()
data = data.replace(b'vertex 10', b'vertex 11')
open('/tmp/altered.stl', 'wb').write(data)
"
python3 validation/run_release_readiness.py \
    --stl /tmp/altered.stl \
    --density tests/fixtures/density/pass_nominal.json

# Regression still passes
python3 validation/run_regression.py
```

---

## 8. Cross-References

| Document | Relation |
|----------|----------|
| `validation/stl/register_fingerprint.py` | STL hash registration CLI |
| `validation/stl/stl_fingerprint_registry.json` | Fingerprint registry (hash storage) |
| `validation/run_release_readiness.py` | Release readiness gate (check #2) |
| `docs/RELEASE_READINESS_GATE_V1.md` | Release gate documentation (§3.2) |
| `manufacturing/MANIFEST_PREPRINT_V1.json` | Manufacturing manifest (gate_0 reference) |
| `docs/STL_GATE_OVERVIEW_V1.md` | Gate chain overview and fingerprint rationale |

---

## 9. Revision History

| Version | Date | Author | Change |
|---------|------|--------|--------|
| V1 | 2026-05-26 | Engineering | Initial STL hash lock documentation |
