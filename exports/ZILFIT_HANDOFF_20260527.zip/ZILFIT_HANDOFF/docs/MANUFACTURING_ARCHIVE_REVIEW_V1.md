# ZILFIT Manufacturing Sample Archive V1

**Document type:** Engineering traceability layer
**Status:** Active
**Archive version:** 1.0
**Authority source:** `sultan_engineering_gate_2`
**Applies to:** Sample-only manufacturing — no production batch authorization
**Date:** 2026-05-26

---

## 1. Purpose

The Manufacturing Sample Archive is the **traceability layer** for every
sample manufacturing attempt. It creates an immutable record that captures
exactly what was approved, printed, measured, reviewed, and blocked or
accepted.

Each archive record is a **single immutable JSON file** stored under
`manufacturing/archive/{sample_id}.json`. Records are never overwritten.
Each `sample_id` is unique across the entire archive.

This layer does **not** replace or duplicate any release readiness gate,
validation gate, regression harness, or manufacturing manifest. It records
what they decided.

---

## 2. Archive Record Schema

### 2.1 Top-Level Fields

| Field | Type | Description |
|-------|------|-------------|
| `archive_type` | string | Always `"manufacturing_sample"` |
| `archive_version` | string | Version of the archive format (e.g., `"1.0"`) |
| `authority_source` | string | Engineering authority that created this record |
| `status` | string | `"SAMPLE_RECORD_CREATED"` or `"BLOCKED_SAMPLE_RECORD"` |
| `sample_id` | string | Unique sample identifier |
| `edition` | string | ZILFIT edition name |
| `created_at` | string | ISO-8601 timestamp of record creation |
| `sample_only_scope` | boolean | Always `true` |
| `sample_only_notice` | string | Scope restriction notice |

### 2.2 Release Readiness Section

| Field | Type | Description |
|-------|------|-------------|
| `release_json_source` | string | Gate name (e.g., `"release_readiness"`) |
| `gate_version` | string | Version of the release readiness gate |
| `print_authorized` | boolean | From release readiness verdict |
| `release_readiness_verdict` | string | `"PASS"` or `"FAIL"` |
| `founder_signoff` | string | `"APPROVED"`, `"PENDING"`, or `"DENIED"` |
| `checked_at` | string | ISO-8601 timestamp of release readiness check |
| `reasons_blocked` | array | Reasons why print was blocked (if applicable) |

### 2.3 Artifacts Section

| Field | Type | Description |
|-------|------|-------------|
| `stl_path` | string | Path to the STL file submitted for print |
| `stl_sha256` | string | SHA-256 hex digest of the STL file |
| `density_authority_path` | string | Path to the density authority JSON |
| `density_authority_sha256` | string | SHA-256 hex digest of the density authority |
| `print_spec_path` | string | Path to the print specification JSON |
| `print_spec_sha256` | string | SHA-256 hex digest of the print spec |

### 2.4 Print Metadata Section

| Field | Type | Description |
|-------|------|-------------|
| `printer_model` | string | Printer model (e.g., `"HP MJF 580"`) |
| `material` | string | Material identifier (e.g., `"TPU_75A_80A"`) |
| `material_batch_id` | string | Material batch or lot ID |
| `operator` | string | Operator name |
| `reviewer` | string | Reviewer name |

### 2.5 Schedule Section

| Field | Type | Description |
|-------|------|-------------|
| `print_started_at` | string | ISO-8601 or `"PENDING"` |
| `print_completed_at` | string | ISO-8601 or `"PENDING"` |

### 2.6 Measurements Section

| Field | Type | Description |
|-------|------|-------------|
| `measured_weight_g` | float or string | Measured weight in grams, or `"PENDING"` |
| `measured_dimensions_mm` | string | Measured dimensions or `"PENDING"` |
| `visual_defects` | string | Visual defect description or `"none"` |
| `dimensional_pass` | boolean or string | `true`, `false`, or `"PENDING"` |
| `comfort_review_status` | string | `"PASS"`, `"FAIL"`, or `"PENDING"` |
| `coupon_test_status` | string | `"PASS"`, `"FAIL"`, or `"PENDING"` |
| `final_review_status` | string | `"PASS"`, `"FAIL"`, or `"PENDING"` |
| `review_notes` | string | Free-text review notes |

### 2.7 Boundary Section

| Field | Type | Description |
|-------|------|-------------|
| `sample_only` | boolean | Always `true` |
| `no_production_batch_authorization` | boolean | Always `true` |
| `no_medical_claims` | boolean | Always `true` |
| `engineering_only` | boolean | Always `true` |

---

## 3. Behaviors

### 3.1 Status Determination

| Release Readiness Verdict | Archive Status | Exit Code |
|---------------------------|---------------|:---------:|
| `PRINT_AUTHORIZED = true` | `SAMPLE_RECORD_CREATED` | 0 |
| `PRINT_AUTHORIZED = false` | `BLOCKED_SAMPLE_RECORD` | 1 |

A `BLOCKED_SAMPLE_RECORD` is still created for **traceability** — even
blocked attempts must be recorded so the engineering team knows what was
blocked and why.

### 3.2 Required Behaviors

| Scenario | Result |
|----------|--------|
| No `--release-json` provided | Exit 1 — "Release readiness JSON not found" |
| Release JSON cannot be parsed | Exit 1 — "Cannot parse release readiness JSON" |
| Release JSON `print_authorized` is not boolean | Exit 1 — validation error |
| Release JSON `print_authorized = false` | Creates `BLOCKED_SAMPLE_RECORD`, exit 1 |
| Release JSON `print_authorized = true` | Creates `SAMPLE_RECORD_CREATED`, exit 0 |
| Duplicate `sample_id` | Exit 1 — "Duplicate sample_id" |
| File already exists at archive path | Exit 1 — race condition guard |
| `final_review_status = PASS` with missing measurements | Exit 1 — requirement error |
| None of these errors | Archive file written under `manufacturing/archive/{sample_id}.json` |

### 3.3 Measurement Validation Rules

- All measurement fields are **optional** and default to `"PENDING"`.
- `final_review_status = "PASS"` **requires** all measurement fields to be
  non-PENDING (weight, dimensions, visual defects, dimensional pass, comfort
  review, coupon test status).
- `dimensional_pass` must be `true`, `false`, or `"PENDING"`.
- `comfort_review_status`, `coupon_test_status`, `final_review_status` must
  be `"PASS"`, `"FAIL"`, or `"PENDING"`.
- `measured_weight_g` must be a number or `"PENDING"`.

---

## 4. How to Run

```bash
# Create archive record from a blocked release readiness run
# First, capture the release readiness JSON
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --json > /tmp/release_blocked.json 2>&1

python3 validation/run_sample_archive.py \
    --release-json /tmp/release_blocked.json \
    --sample-id ZILFIT-CALM-0001 \
    --edition CALM \
    --printer-model "HP MJF 580" \
    --material TPU_75A_80A \
    --material-batch-id "TPU-2026-05-B012" \
    --operator "Sultan" \
    --reviewer "Sultan"

# Create archive record with measurement data
python3 validation/run_sample_archive.py \
    --release-json /tmp/release_approved.json \
    --sample-id ZILFIT-CALM-0002 \
    --edition CALM \
    --printer-model "HP MJF 580" \
    --material TPU_75A_80A \
    --material-batch-id "TPU-2026-05-B012" \
    --operator "Sultan" \
    --reviewer "Sultan" \
    --measured-weight-g 42.5 \
    --measured-dimensions-mm "250.2x85.1x12.8" \
    --visual-defects "none" \
    --dimensional-pass true \
    --comfort-review-status "PASS" \
    --coupon-test-status "PENDING" \
    --final-review-status "PENDING" \
    --review-notes "First sample. Dimensional check passed."

# Machine-readable JSON output
python3 validation/run_sample_archive.py \
    --release-json /tmp/release_approved.json \
    --sample-id ZILFIT-CALM-0003 \
    --edition CALM \
    --printer-model "HP MJF 580" \
    --material TPU_75A_80A \
    --material-batch-id "TPU-2026-05-B012" \
    --operator "Sultan" \
    --reviewer "Sultan" \
    --json
```

---

## 5. Verification Commands

```bash
# Syntax
python3 -m py_compile validation/run_sample_archive.py

# 1. Missing release JSON → exit 1
python3 validation/run_sample_archive.py \
    --release-json /tmp/nonexistent.json \
    --sample-id ZILFIT-CALM-TEST-001 \
    --edition CALM \
    --printer-model "HP MJF 580" \
    --material TPU_75A_80A \
    --material-batch-id "TPU-2026-05-B012" \
    --operator "Sultan" \
    --reviewer "Sultan"; echo "EXIT: $?"

# 2. Blocked release JSON → creates BLOCKED_SAMPLE_RECORD, exit 1
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --json > /tmp/release_blocked.json 2>&1; echo "RELEASE EXIT: $?"
python3 validation/run_sample_archive.py \
    --release-json /tmp/release_blocked.json \
    --sample-id ZILFIT-CALM-TEST-002 \
    --edition CALM \
    --printer-model "HP MJF 580" \
    --material TPU_75A_80A \
    --material-batch-id "TPU-2026-05-B012" \
    --operator "Sultan" \
    --reviewer "Sultan"; echo "EXIT: $?"

# 3. Approved release JSON fixture → creates SAMPLE_RECORD_CREATED, exit 0
python3 validation/run_sample_archive.py \
    --release-json tests/fixtures/release/approved_release_v1.json \
    --sample-id ZILFIT-CALM-TEST-003 \
    --edition CALM \
    --printer-model "HP MJF 580" \
    --material TPU_75A_80A \
    --material-batch-id "TPU-2026-05-B012" \
    --operator "Sultan" \
    --reviewer "Sultan"; echo "EXIT: $?"

# 4. Duplicate sample_id → exit 1
python3 validation/run_sample_archive.py \
    --release-json tests/fixtures/release/approved_release_v1.json \
    --sample-id ZILFIT-CALM-TEST-003 \
    --edition CALM \
    --printer-model "HP MJF 580" \
    --material TPU_75A_80A \
    --material-batch-id "TPU-2026-05-B012" \
    --operator "Sultan" \
    --reviewer "Sultan"; echo "EXIT: $?"

# 5. final_review_status PASS with missing measurements → exit 1
python3 validation/run_sample_archive.py \
    --release-json tests/fixtures/release/approved_release_v1.json \
    --sample-id ZILFIT-CALM-TEST-004 \
    --edition CALM \
    --printer-model "HP MJF 580" \
    --material TPU_75A_80A \
    --material-batch-id "TPU-2026-05-B012" \
    --operator "Sultan" \
    --reviewer "Sultan" \
    --final-review-status PASS; echo "EXIT: $?"

# Git
git diff --stat
git status --short
```

---

## 6. Boundaries

| Topic | Status |
|-------|--------|
| Production batch authorization | **Explicitly excluded** — sample-only scope |
| STL modification | **Excluded** — archive reads STL only for hash computation |
| Print spec modification | **Excluded** — archive reads spec only for hash computation |
| Hash mutation | **Excluded** — hashes are computed, never modified |
| Silent overwrite | **Excluded** — `open(..., "x")` ensures no overwrite |
| Network access | **Excluded** — all operations are local |
| Medical, therapeutic, clinical claims | **Excluded** — engineering-only |

---

## 7. Cross-References

| Document | Relation |
|----------|----------|
| `manufacturing/archive/` | Archive directory (one JSON file per sample) |
| `validation/run_sample_archive.py` | Archive CLI tool |
| `validation/run_release_readiness.py` | Release readiness gate (provides input JSON) |
| `docs/RELEASE_READINESS_GATE_V1.md` | Release gate documentation |
| `docs/PRINT_SPEC_AUTHORITY_V1.md` | Print specification authority layer |
| `docs/STL_HASH_LOCK_V1.md` | STL hash lock layer |
| `manufacturing/ACCEPTANCE_CRITERIA_V1.md` | Acceptance criteria for first physical print |
| `docs/COUPON_TEST_READINESS_PLAN_V1.md` | Coupon test definitions |

---

## 8. Revision History

| Version | Date | Author | Change |
|---------|------|--------|--------|
| V1 | 2026-05-26 | Engineering | Initial manufacturing sample archive layer |
