# ZILFIT Print Specification Authority V1

**Document type:** Engineering release authority
**Status:** Active
**Spec version:** 1.0
**Authority source:** `sultan_engineering_gate_2`
**Applies to:** Sample-only manufacturing — no production batch authorization
**Date:** 2026-05-26

---

## 1. Purpose

The Print Specification Authority defines the **immutable TPU printing
configuration** that must be locked before any sample manufacturing can
proceed. It is the engineering contract between the validated design (STL +
density) and the manufacturing process (MJF, TPU 75A-80A).

This is a **prevention** layer, not a generation layer. The print spec
artifact is authored by an engineer, reviewed, signed (hash-locked), and
then verified at release time. No slicer automation, no runtime spec
generation, no geometry processing.

---

## 2. Spec Artifact

The canonical print specification is at:
`manufacturing/print_specs/TPU_75A_80A_MJF_SAMPLE_V1.json`

### 2.1 Schema

The spec is a JSON document with the following fields:

| Field | Type | Description |
|-------|------|-------------|
| `$schema` | string | JSON Schema reference |
| `title` | string | Spec title |
| `description` | string | Scope and boundary note |
| `spec_version` | string | Version of the spec format (e.g., "1.0") |
| `spec_name` | string | Unique spec name (e.g., "TPU_75A_80A_MJF_SAMPLE_V1") |
| `authority_source` | string | Engineering authority that approved this spec |
| `status` | string | "active" or "deprecated" |
| `material_family` | string | Material identifier (e.g., "TPU_75A_80A") |
| `manufacturing_process` | string | Primary process code (e.g., "MJF") |
| `manufacturing_process_full` | string | Full process name |
| `layer_height_mm` | number | Layer height in millimeters |
| `wall_perimeter_count` | integer | Number of wall/perimeter passes |
| `infill_percent` | integer | Infill density percentage |
| `infill_pattern` | string | Infill geometry pattern (e.g., "gyroid") |
| `print_speed` | string | Print speed profile |
| `bed_temp_c` | integer | Build chamber / bed temperature in °C |
| `nozzle_size_mm` | string | Nozzle diameter or MJF note |
| `nozzle_temp_c` | string | Nozzle temperature or MJF note |
| `cooling_policy` | string | Cooling strategy after print |
| `orientation_notes` | string | Recommended build orientation |
| `support_policy` | string | Support structure requirements |
| `drying_requirement` | string | Material drying specification |
| `sample_only_restriction` | boolean | **Must be `true`** — prohibits production use |
| `not_for_batch_production` | boolean | **Must be `true`** — prohibits batch runs |
| `boundary` | object | Additional boundary statements |
| `spec_hash` | string | SHA-256 hex digest of all other fields |

### 2.2 Hash Locking

The `spec_hash` field is a SHA-256 computed over the canonical JSON
representation of all **other** fields in the spec (sorted keys, no
whitespace, no `spec_hash` field). This makes the spec self-validating.

```python
import hashlib, json

spec_copy = dict(spec)
spec_copy.pop("spec_hash", None)
canonical = json.dumps(spec_copy, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
spec_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
```

If any field changes after signing, the computed hash will differ from the
declared hash, and the release readiness gate will block the print.

---

## 3. Release Readiness Integration

The release readiness gate checks print spec authority as check #8
(`print_spec_authority`):

### Required Behaviors

| Scenario | Expected Result |
|----------|----------------|
| No `--print-spec` provided | **BLOCKED** — FAIL with "No print spec provided" |
| Spec file not found | **BLOCKED** — FAIL with "Print spec file not found" |
| Spec JSON cannot be parsed | **BLOCKED** — FAIL with "Print spec cannot be parsed" |
| Spec missing `spec_hash` field | **BLOCKED** — FAIL with "missing 'spec_hash' field" |
| Spec hash mismatch (tampered) | **BLOCKED** — FAIL with "hash mismatch — spec has been modified after signing" |
| Spec missing required fields | **BLOCKED** — FAIL with "missing required field(s)" |
| `sample_only_restriction` not `true` | **BLOCKED** — FAIL with "sample_only_restriction must be True" |
| `not_for_batch_production` not `true` | **BLOCKED** — FAIL with "not_for_batch_production must be True" |
| All checks pass | **PASS** — spec name, version, hash, and sample-only status reported |

**Important:** `PRINT_AUTHORIZED` remains `false` unless **all** checks
(including manifest, fingerprint, validation runner, regression, material,
wall, density, and founder sign-off) pass.

---

## 4. How to Run

```bash
# Release readiness with default print spec
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --founder-signoff APPROVED

# Release readiness without print spec (should BLOCK)
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --no-print-spec

# Release readiness with explicit spec path
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --print-spec manufacturing/print_specs/TPU_75A_80A_MJF_SAMPLE_V1.json \
    --founder-signoff APPROVED

# Verify spec hash independently
python3 -c "
import hashlib, json
spec = json.load(open('manufacturing/print_specs/TPU_75A_80A_MJF_SAMPLE_V1.json'))
declared = spec.pop('spec_hash')
canonical = json.dumps(spec, sort_keys=True, separators=(',', ':'), ensure_ascii=True)
computed = hashlib.sha256(canonical.encode('utf-8')).hexdigest()
ok = computed == declared
print('spec_hash:', 'MATCH' if ok else 'MISMATCH')
print('declared:', declared[:20] + '...')
print('computed:', computed[:20] + '...')
"
```

---

## 5. Tamper Detection Example

If the print spec is modified after signing, the hash will not match:

```bash
# Copy spec and alter a parameter
cp manufacturing/print_specs/TPU_75A_80A_MJF_SAMPLE_V1.json /tmp/tampered_spec.json
python3 -c "
import json
spec = json.load(open('/tmp/tampered_spec.json'))
spec['layer_height_mm'] = 0.15  # tamper with a parameter
json.dump(spec, open('/tmp/tampered_spec.json', 'w'), indent=2)
"

# Run release readiness — print_spec_authority should FAIL
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --print-spec /tmp/tampered_spec.json \
    --json | python3 -c "import sys,json; d=json.load(sys.stdin); print('print_spec_authority:', [c for c in d['checks'] if c['check']=='print_spec_authority'][0])"
```

Expected: `print_spec_authority: FAIL` with "hash mismatch — spec has been modified after signing".

---

## 6. Boundaries

| Topic | Status |
|-------|--------|
| Production batch authorization | **Explicitly excluded** — `not_for_batch_production: true` |
| Slicer automation | **Excluded** — spec is human-authored, not machine-generated |
| STL modification or repair | **Excluded** — spec is independent of STL content |
| Network access | **Excluded** — all operations are local |
| Medical, therapeutic, or clinical claims | **Excluded** — engineering-only |

---

## 7. Verification Commands

```bash
# Syntax
python3 -m py_compile validation/run_release_readiness.py

# Release readiness with valid print spec (still BLOCKED — no signoff)
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json

# Release readiness without print spec (should BLOCK)
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --no-print-spec

# Release readiness with tampered spec
cp manufacturing/print_specs/TPU_75A_80A_MJF_SAMPLE_V1.json /tmp/tampered_spec.json
python3 -c "
import json
spec = json.load(open('/tmp/tampered_spec.json'))
spec['layer_height_mm'] = 0.15
json.dump(spec, open('/tmp/tampered_spec.json', 'w'), indent=2)
"
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --print-spec /tmp/tampered_spec.json

# Regression still passes
python3 validation/run_regression.py

# Git
git diff --stat
git status --short
```

---

## 8. Cross-References

| Document | Relation |
|----------|----------|
| `manufacturing/print_specs/TPU_75A_80A_MJF_SAMPLE_V1.json` | Canonical print spec artifact |
| `validation/run_release_readiness.py` | Release readiness gate (check #8) |
| `docs/RELEASE_READINESS_GATE_V1.md` | Release gate documentation (§3.8) |
| `manufacturing/MATERIAL_PROFILE_TPU75A_80A_V1.md` | Material properties and print params |
| `manufacturing/ACCEPTANCE_CRITERIA_V1.md` | Acceptance criteria for first physical print |
| `docs/STL_HASH_LOCK_V1.md` | STL hash lock (preceding authority layer) |
| `docs/COUPON_TEST_READINESS_PLAN_V1.md` | Coupon test definitions CT-01 through CT-06 |

---

## 9. Revision History

| Version | Date | Author | Change |
|---------|------|--------|--------|
| V1 | 2026-05-26 | Engineering | Initial print specification authority |
