# ZILFIT — Headless OrcaSlicer Simulation Pipeline

**Version:** 1.0.0  
**Scope:** `simulation/` · `validation/run_simulation_pipeline.py` · `docker/simulation/`  
**Status:** Patch 3A — Pre-production gate, sample-only  
**Restriction:** `SAMPLE_ONLY — NOT FOR BATCH PRODUCTION`

---

## 1. Purpose

Create a deterministic pre-print simulation pipeline that validates an STL file
against the approved TPU print specification *before* physical manufacturing.

The pipeline:

1. Runs OrcaSlicer **headless** inside a reproducible Docker container
2. Generates deterministic G-code using fixed config profiles
3. Parses the G-code to extract manufacturing metrics
4. Detects obvious printing risks (bridges, overhangs, thin walls, high flow)
5. Outputs a structured simulation report + all artifacts

This does **not** authorize production. It is an engineering validation layer.

---

## 2. Architecture

```
┌──────────────┐    ┌──────────────────┐    ┌────────────────┐
│  STL file     │    │  Print Spec JSON │    │  OrcaSlicer    │
│  (.stl)       │───▶│  (default_tpu)   │───▶│  Configs       │
└──────────────┘    └──────────────────┘    │  (printer,      │
                                            │   process,      │
                                            │   filament)     │
                                            └───────┬────────┘
                                                    │
                                                    ▼
                                        ┌──────────────────────┐
                                        │  Docker Container    │
                                        │  (xvfb + mesa)       │
                                        │  ┌────────────────┐  │
                                        │  │  OrcaSlicer    │  │
                                        │  │  --slice 0     │  │
                                        │  │  --headless    │  │
                                        │  └────────┬───────┘  │
                                        └───────────┼──────────┘
                                                    │
                                                    ▼
                                        ┌──────────────────────┐
                                        │   Output Directory   │
                                        │  ├── *.gcode         │
                                        │  ├── slicing.log     │
                                        │  └── simulation_     │
                                        │       report.json    │
                                        └──────────────────────┘
```

---

## 3. Simulation Report Schema

| Field | Type | Description |
|-------|------|-------------|
| `report_version` | string | Schema version (currently `1.0.0`) |
| `stl_path` | string | Source STL file path |
| `stl_sha256` | string | SHA-256 of input STL |
| `print_spec_path` | string | Source print spec JSON path |
| `print_spec_sha256` | string | SHA-256 of canonical print spec |
| `gcode_path` | string\|null | Generated G-code file path |
| `gcode_sha256` | string | SHA-256 of generated G-code |
| `slicer_version` | string | OrcaSlicer version from G-code header |
| `estimated_print_time_s` | int | Estimated print time in seconds |
| `estimated_filament_mm` | float | Estimated filament length (mm) |
| `estimated_filament_g` | float | Estimated filament weight (g) |
| `layer_count` | int | Number of layers in the G-code |
| `max_flow_mm3_s` | float | Maximum volumetric flow detected |
| `support_material_used` | bool | Whether support structures are generated |
| `bridge_regions_detected` | bool | Whether bridge extrusions exist |
| `overhang_regions_detected` | bool | Whether overhang extrusions exist |
| `thin_wall_regions_detected` | bool | Whether thin wall extrusions exist |
| `warnings[]` | string[] | Manufacturing risk warnings |
| `simulation_status` | string | `SUCCESS` or `FAILED` |
| `sample_only_restriction` | bool | Always `true` |
| `docker_build` | string | Docker image build status message |
| `created_at` | string | ISO 8601 timestamp |

---

## 4. Required Behaviors

| # | Condition | Result |
|---|-----------|--------|
| 1 | Missing STL file | Exit 1 — "STL file not found" |
| 2 | Missing print spec file | Exit 1 — "Print spec file not found" |
| 3 | Missing OrcaSlicer config files | Exit 1 — individual file errors |
| 4 | Print spec missing required fields | Exit 1 — field-level errors |
| 5 | Docker image not built yet | Auto-builds on first run |
| 6 | Docker build fails | Exit 1 — build error details |
| 7 | OrcaSlicer slicing fails (no G-code generated) | Exit 1 — FAILED status, warnings |
| 8 | OrcaSlicer slicing succeeds | Exit 0 — SUCCESS status, full report |
| 9 | Deterministic re-run (same STL + spec) | Identical G-code SHA-256 |
| 10 | `--json` flag | Machine-readable report to stdout |

---

## 5. Usage

### Basic simulation
```bash
python3 validation/run_simulation_pipeline.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --print-spec tests/fixtures/print_specs/default_tpu.json \
    --output-dir simulation/output/test_cube \
    --headless \
    --json
```

### Skip Docker image rebuild (use cached image)
```bash
python3 validation/run_simulation_pipeline.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --print-spec tests/fixtures/print_specs/default_tpu.json \
    --output-dir simulation/output/test_cube \
    --skip-docker-build \
    --json
```

### Custom OrcaSlicer config paths
```bash
python3 validation/run_simulation_pipeline.py \
    --stl tests/fixtures/stl/my_design.stl \
    --print-spec tests/fixtures/print_specs/default_tpu.json \
    --orca-printer /path/to/printer.json \
    --orca-process /path/to/process.json \
    --orca-filament /path/to/filament.json \
    --output-dir simulation/output/my_design \
    --json
```

---

## 6. Docker Container Details

| Property | Value |
|----------|-------|
| Base image | `ubuntu:24.04` |
| OrcaSlicer version | `v2.3.2` (AppImage extracted) |
| GPU rendering | Mesa software rendering (no GPU required) |
| Display server | `xvfb` (virtual framebuffer) |
| Image tag | `zilfit/simulation:latest` |
| Workspace | `/workspace/input/`, `/workspace/output/`, `/workspace/configs/` |
| Entrypoint | `entrypoint.sh` — wraps orca-slicer with `xvfb-run` |

### Building manually
```bash
docker build -t zilfit/simulation:latest -f docker/simulation/Dockerfile .
```

---

## 7. G-code Parsing Details

The pipeline parses OrcaSlicer-generated G-code comments to extract metrics:

| Metric | G-code Pattern |
|--------|----------------|
| Slicer version | `; generated by OrcaSlicer X.Y.Z` |
| Filament length | `; filament used [mm] = X.X` |
| Filament weight | `; filament used [g] = X.X` |
| Print time | `; estimated printing time (normal mode) = Xh Ym Zs` |
| Layer count | Count of `;LAYER:\d+` lines |
| Support | Presence of `;TYPE:Support material` |
| Bridge | Presence of `;TYPE:Bridge infill` |
| Overhang | Presence of `;TYPE:Overhang wall` |
| Thin wall | Presence of `;TYPE:Thin wall` |
| Max volumetric flow | Parsed from `G1 X Y Z E F` moves |

---

## 8. Output Structure

```
simulation/output/<run_name>/
├── model_*.gcode                  # Generated G-code
├── slicing.log                    # OrcaSlicer stdout/stderr
└── simulation_report.json         # Structured simulation report
```

---

## 9. Boundaries & Restrictions

| Boundary | Rule |
|----------|------|
| Sample-only | All outputs carry `sample_only_restriction: true` |
| No production auth | Simulation does not authorize batch production |
| No STL mutation | Pipeline is read-only on the input STL |
| No network | Docker container has no network access at runtime |
| No `shell=True` | All subprocess calls use explicit `subprocess.run()` with lists |
| No CI integration | No automated CI/CD pipeline integration |
| No slicer automation | OrcaSlicer-specific — not a generic slicer abstraction |
| No print spec modification | Print spec is read-only, not modified by the pipeline |

---

## 10. Verification

```bash
# Syntax check
python3 -m py_compile validation/run_simulation_pipeline.py

# Missing STL
python3 validation/run_simulation_pipeline.py \
    --stl /tmp/nonexistent.stl \
    --print-spec tests/fixtures/print_specs/default_tpu.json \
    --headless; echo $?

# Missing print spec
python3 validation/run_simulation_pipeline.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --print-spec /tmp/nonexistent.json \
    --headless; echo $?

# Full simulation (requires Docker)
python3 validation/run_simulation_pipeline.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --print-spec tests/fixtures/print_specs/default_tpu.json \
    --output-dir simulation/output/test_cube \
    --headless --json

# Determinism check (requires Docker)
python3 validation/run_simulation_pipeline.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --print-spec tests/fixtures/print_specs/default_tpu.json \
    --output-dir simulation/output/test_cube_rerun \
    --skip-docker-build --json \
    | python3 -c "import sys,json; print(json.load(sys.stdin)['gcode_sha256'])"
```

---

## 11. Cross-References

| Document | Relation |
|----------|----------|
| `docs/RELEASE_READINESS_GATE_V1.md` | Simulation is a pre-gate check (Phase 2) |
| `docs/PRINT_SPEC_AUTHORITY_V1.md` | Print spec defines the slicing parameters |
| `docs/STL_GATE_OVERVIEW_V1.md` | STL must pass gates before simulation |
| `validation/run_release_readiness.py` | Consumes simulation results for gate 9 |
| `manufacturing/print_specs/TPU_75A_80A_MJF_SAMPLE_V1.json` | MJF print spec (alternative process) |

---

## Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0   | 2026-05-26 | ZILFIT | Initial specification — Patch 3A |
