# ZILFIT Manufacturing Release Readiness Gate V1

**Document type:** Engineering release authority
**Status:** Pre-print — not yet authorized
**Gate version:** 1.0
**Authority source:** `sultan_engineering_gate_2`
**Applies to:** Sample-only manufacturing — no production batch authorization
**Date:** 2026-05-26

---

## 1. Purpose

The Release Readiness Gate is the **final engineering gate** before a candidate
STL + density authority combination is allowed to proceed to **sample-only
manufacturing**. It aggregates all lower-level validation results and applies
policy-level checks that only make sense at the release decision boundary.

This gate does **not** replace:

- Gate 1A — Manifold validation (`validation/stl/check_manifold.py`)
- Gate 1B — Wall thickness validation (`validation/stl/check_wall_thickness.py`)
- Gate 1C — Density jump validation (`validation/density/check_density_jump_cap.py`)
- The unified runner (`validation/run_preprint.py`)
- The regression harness (`validation/run_regression.py`)
- The STL fingerprint registry (`validation/stl/stl_fingerprint_registry.json`)
- The manufacturing manifest (`manufacturing/MANIFEST_PREPRINT_V1.json`)

It **aggregates their results** and produces a single `PRINT_AUTHORIZED` boolean.

---

## 2. Gate Chain

```
                    ┌───────────────────────────────────┐
                    │  RELEASE READINESS GATE V1         │ ◄— THIS DOCUMENT
                    │  validation/run_release_readiness   │
                    │  .py                               │
                    │                                    │
                    │  1. manifest_authority             │
                    │  2. stl_fingerprint_lock           │
                    │  3. validation_runner              │
                    │  4. regression_baseline            │
                    │  5. material_consistency           │
                    │  6. wall_threshold_compliance      │
                    │  7. density_cap_compliance         │
                    │  8. print_spec_authority          │
                    │  9. founder_signoff                │
                    └───────────────┬───────────────────┘
                                    │
                    ┌───────────────▼───────────────────┐
                    │  Unified Runner                    │
                    │  validation/run_preprint.py        │
                    ├──────────────┬──────────────────┐
                    │              │                  │
              ┌─────▼─────┐ ┌──────▼──────┐ ┌────────▼──────┐
              │ Gate 1A   │ │ Gate 1B     │ │ Gate 1C       │
              │ Manifold  │ │ Wall Thick  │ │ Density Jump  │
              └───────────┘ └─────────────┘ └───────────────┘
                                    │
                    ┌───────────────▼───────────────────┐
                    │  Regression Harness                │
                    │  validation/run_regression.py     │
                    └───────────────────────────────────┘
```

All lower-level gates and the regression harness must pass before the release
readiness gate can authorize a print.

---

## 3. Checks

### 3.1 Manifest Authority

| Property | Value |
|----------|-------|
| Input | `manufacturing/MANIFEST_PREPRINT_V1.json` |
| Pass | File exists, `status == "pre_print"`, parseable |
| Fail | File missing, unparseable, or status is not `pre_print` |

Verifies that the manufacturing manifest exists and reports a `pre_print`
status. This ensures no print proceeds under an unknown or expired manifest.

---

### 3.2 STL Fingerprint Lock

| Property | Value |
|----------|-------|
| Input | STL file + `validation/stl/stl_fingerprint_registry.json` |
| Pass | STL SHA-256 hash found in registry for at least one edition |
| Fail | Registry empty, STL hash not found, or hash unavailable |

Every STL submitted for print must carry a **registered fingerprint** in the
fingerprint registry. If the mesh changes (re-export, rounding change, vertex
reordering), the hash changes and this check blocks the print.

The fingerprint is computed using SHA-256 of the entire STL file contents.
This differs from the canonical fingerprint contract
(`runtime/zilfit_fingerprint_contract.py`) which operates on extracted mesh
data. The release gate uses file-level hashing because it is the simplest
deterministic check for "has this exact file been registered?"

**Current state:** Registry is empty. This check will fail until the first
real STL export is registered.

---

### 3.3 Validation Runner

| Property | Value |
|----------|-------|
| Input | STL file + density authority JSON |
| Pass | `validation/run_preprint.py --json` exits 0, `verdict == "PASS"` |
| Fail | Exit non-zero, verdict not PASS, or runner unavailable |

Runs the unified pre-print validation runner (gates 1A, 1B, 1C) and verifies
the overall verdict is PASS. This is the most important check — it confirms
that the STL is manifold, wall thickness is acceptable, and density jumps are
within limits.

---

### 3.4 Regression Baseline

| Property | Value |
|----------|-------|
| Input | None (runs regression harness) |
| Pass | `validation/run_regression.py` exits 0 |
| Fail | Exit non-zero, or baseline cannot be established |

Runs the full regression harness and verifies all 11 cases pass. This ensures
that the validation infrastructure itself has not drifted — no silent contract
changes, no broken fixtures, no constant changes.

---

### 3.5 Material Consistency

| Property | Value |
|----------|-------|
| Input | Density authority JSON |
| Pass | `data["material"] == "TPU_75A_80A"` |
| Fail | Material is missing, wrong, or unparseable |

Verifies the density authority file declares `TPU_75A_80A` as the material.
If the material has changed, all existing simulation evidence is invalidated,
and a separate material qualification gate is required.

---

### 3.6 Wall Threshold Compliance

| Property | Value |
|----------|-------|
| Input | Gate 1B result (from validation runner) |
| Pass | Gate 1B status == `PASS` |
| Fail | Gate 1B status is `HARD_FAIL`, `SOFT_FAIL`, or `INPUT_ERROR` |

Confirms the wall thickness gate passed. The production floor is `MIN_WALL_MM
= 0.8 mm` for TPU 75A–80A. Any wall below 0.8 mm blocks the print.

---

### 3.7 Density Cap Compliance

| Property | Value |
|----------|-------|
| Input | Gate 1C result (from validation runner) |
| Pass | Gate 1C status == `PASS` |
| Fail | Gate 1C status is `HARD_FAIL` or `SOFT_FAIL` |

Confirms the density jump gate passed. The maximum adjacent zone density
delta is `MAX_DELTA = 0.15`. Any delta exceeding this blocks the print.

---

### 3.8 Print Spec Authority

| Property | Value |
|----------|-------|
| Input | `manufacturing/print_specs/TPU_75A_80A_MJF_SAMPLE_V1.json` or `--print-spec` CLI argument |
| Pass | Spec file exists, `spec_hash` matches computed hash, all required fields present, `sample_only_restriction == true`, `not_for_batch_production == true` |
| Fail | Spec missing, unparseable, hash mismatch, missing fields, or scope flags not `true` |

Verifies that the print specification artifact exists, is hash-locked, and
carries the correct sample-only scope restrictions. The spec defines the
immutable TPU printing configuration for sample manufacturing.

The `spec_hash` is computed as SHA-256 over all other fields (canonical
JSON, sorted keys, no whitespace). Any modification after signing changes
the hash and blocks the print.

See `docs/PRINT_SPEC_AUTHORITY_V1.md` for full documentation.

---

### 3.9 Founder Sign-Off

| Property | Value |
|----------|-------|
| Input | `--founder-signoff` CLI argument |
| Pass | Value is `APPROVED` |
| Fail | Value is `PENDING` or `DENIED` |

Requires explicit founder approval before any print proceeds. This is the
final human-in-the-loop check before a physical sample is manufactured.

---

## 4. Go/No-Go Rules

`PRINT_AUTHORIZED = True` **only if** all 9 checks pass.

| # | Check | Must be |
|---|-------|---------|
| 1 | manifest_authority | PASS |
| 2 | stl_fingerprint_lock | PASS |
| 3 | validation_runner | PASS |
| 4 | regression_baseline | PASS |
| 5 | material_consistency | PASS |
| 6 | wall_threshold_compliance | PASS |
| 7 | density_cap_compliance | PASS |
| 8 | print_spec_authority | PASS |
| 9 | founder_signoff | PASS |

If any check fails:
- `PRINT_AUTHORIZED = False`
- The failing check's reason is appended to `reasons_blocked`
- A human-readable BLOCKED report is printed

---

## 5. What This Gate Does NOT Validate

The following are explicitly **out of scope** for this gate V1:

| Topic | Why excluded |
|-------|-------------|
| Production batch authorization | Sample-only scope — no multi-unit or batch production |
| Multi-edition validation | Single-edition pilot required first |
| Sensor housing readiness | No sensor housing CAD or electronics design exists |
| Outsole bonding readiness | No bonding process defined |
| Human comfort / wear trials | Gate 6 per manifest — not required before first sample |
| SLS printability | SLS is deferred per manifest |
| AMFuture file pack completeness | Production file pack handoff is a separate track |
| Physical coupon tests (CT-01 to CT-06) | Coupon tests are gates 3–5 per manifest — required before full-sole print but not before sample authorization |
| Medical, therapeutic, clinical claims | All ZILFIT outputs are engineering-only |

These exclusions are explicitly documented and not hidden. If any of these
become required for a future gate version, a new check will be added to the
release readiness layer.

---

## 6. Boundary Statements

```
sample_only_scope:                 true
no_production_batch_authorization: true
no_medical_claims:                 true
engineering_only:                  true
```

PRINT_AUTHORIZED under this gate authorizes **sample-only manufacturing**.
Full-sole prints, multi-edition batch runs, and production-scale manufacturing
are explicitly excluded and require additional governance approval.

---

## 7. How to Run

```bash
# Full release readiness check (all 9 checks)
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json

# With founder sign-off
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --founder-signoff APPROVED

# With explicit manifest and registry paths
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --manifest manufacturing/MANIFEST_PREPRINT_V1.json \
    --fingerprint-registry validation/stl/stl_fingerprint_registry.json

# Machine-readable JSON output
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --json
```

All expected to return exit 1 (BLOCKED) until the fingerprint registry is
populated AND founder sign-off is provided.

---

## 8. Verification Commands

```bash
# Syntax
python3 -m py_compile validation/run_release_readiness.py

# Gate scenarios
python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json

python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/pass_nominal.json \
    --founder-signoff APPROVED

python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/nonmanifold_5edge.stl \
    --density tests/fixtures/density/pass_nominal.json

python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/thinwall_05mm.stl \
    --density tests/fixtures/density/pass_nominal.json

python3 validation/run_release_readiness.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --density tests/fixtures/density/soft_fail_delta_016.json

# Git
git diff --stat
git status --short
```

---

## 9. Cross-References

| Document | Relation |
|----------|----------|
| `validation/run_release_readiness.py` | Release readiness gate runner (9 checks) |
| `validation/run_preprint.py` | Unified pre-print validation runner |
| `validation/run_regression.py` | Local regression validation harness |
| `validation/stl/stl_fingerprint_registry.json` | STL fingerprint registry (gate 0) |
| `manufacturing/MANIFEST_PREPRINT_V1.json` | Gate statuses, holds, locked constants |
| `manufacturing/MATERIAL_PROFILE_TPU75A_80A_V1.md` | TPU 75A–80A material properties |
| `manufacturing/ACCEPTANCE_CRITERIA_V1.md` | Acceptance criteria for first physical print |
| `docs/PRINT_SPEC_AUTHORITY_V1.md` | Print specification authority layer |
| `docs/STL_GATE_OVERVIEW_V1.md` | Gate chain overview, fingerprint rationale |
| `docs/WALL_THICKNESS_GATE_V1.md` | Wall thickness gate rationale and constants |
| `docs/COUPON_TEST_READINESS_PLAN_V1.md` | Coupon test definitions CT-01 through CT-06 |
| `docs/ZILFIT_DENSITY_TO_PRINT_SPEC_CONTRACT_V1.md` | Density-to-wall-thickness contract |
| `docs/prototype_first_production_readiness.md` | Prototype-first workflow |
| `validation/run_sample_archive.py` | Manufacturing sample archive (traceability layer) |
| `docs/MANUFACTURING_ARCHIVE_REVIEW_V1.md` | Archive record schema and procedures |

---

## 10. Hash Lock Registration Procedure

To register an STL file's SHA-256 hash in the fingerprint registry:

```bash
# Register a known-good STL (e.g., cube watertight fixture)
python3 validation/stl/register_fingerprint.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --edition test_cube

# Verify without registering (dry-run)
python3 validation/stl/register_fingerprint.py \
    --stl tests/fixtures/stl/cube_watertight.stl \
    --check-only

# List all registered hashes
python3 -c "import json; r=json.load(open('validation/stl/stl_fingerprint_registry.json')); [print(f\"  {e['edition']}: {e['sha256'][:16]}... ({e['validated_at']})\") for e in r['registry']]"
```

**Rules:**
- Only sample-only STL files may be registered
- Each STL must be manually validated before registration
- Registration does not authorize printing — all 9 checks must still pass
- If the STL is re-exported, its hash changes and it must be re-registered

See `docs/STL_HASH_LOCK_V1.md` for full documentation.

---

## 11. Revision History

| Version | Date | Author | Change |
|---------|------|--------|--------|
| V1.2 | 2026-05-26 | Engineering | Added print spec authority check (§3.8), now 9 checks, print spec path in header |
| V1.1 | 2026-05-26 | Engineering | Added hash lock registration procedure (§10), hash lock check now operational |
| V1 | 2026-05-26 | Engineering | Initial release readiness gate for sample-only manufacturing |
