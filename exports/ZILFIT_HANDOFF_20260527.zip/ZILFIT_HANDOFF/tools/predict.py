import sys
import joblib
import pandas as pd

model = joblib.load("production_inputs/csv_results/foot_model.pkl")

features = {
    "vertices": float(sys.argv[1]),
    "foot_length_mm": float(sys.argv[2]),
    "foot_width_mm": float(sys.argv[3]),
    "forefoot_width_mm": float(sys.argv[4]),
    "arch_height_geometric_mm": float(sys.argv[5]),
    "alignment_offset_deg": float(sys.argv[6]),
    "arch_contact_ratio": float(sys.argv[7]),
}

df = pd.DataFrame([features])

pred = model.predict(df)[0]
proba = model.predict_proba(df)[0]

classes = model.classes_

confidence = max(proba)

print("\nPrediction:", pred)
print("Confidence:", round(confidence, 4))

print("\nProbabilities:")
for c, p in zip(classes, proba):
    print(c, round(p, 4))
