import pandas as pd

df = pd.read_csv("production_inputs/csv_results/results.csv")

def classify(v):
    try:
        v = float(v)
    except:
        return "unknown"

    if v > 0.26:
        return "flat_foot"
    elif v < 0.12:
        return "high_arch"
    else:
        return "normal"

df["classification"] = df["arch_contact_ratio"].apply(classify)

df.to_csv(
    "production_inputs/csv_results/labeled_results.csv",
    index=False
)

print(df[["scan_id","arch_contact_ratio","classification"]].head())
print("Saved labeled dataset.")
