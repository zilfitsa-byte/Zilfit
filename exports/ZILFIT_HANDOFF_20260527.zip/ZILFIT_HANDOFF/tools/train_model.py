import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
import joblib

df = pd.read_csv("production_inputs/csv_results/all_results.csv")

def classify(v):
    v = float(v)
    if v > 0.26:
        return "flat_foot"
    elif v < 0.12:
        return "high_arch"
    return "normal"

df["label"] = df["arch_contact_ratio"].apply(classify)

features = [
    "vertices",
    "foot_length_mm",
    "foot_width_mm",
    "forefoot_width_mm",
    "arch_height_geometric_mm",
    "alignment_offset_deg",
    "arch_contact_ratio"
]

X = df[features]
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

model = RandomForestClassifier(
    n_estimators=200,
    max_depth=10,
    random_state=42
)

model.fit(X_train, y_train)

pred = model.predict(X_test)

print("\nAccuracy:", accuracy_score(y_test, pred))
print("\nClassification Report:\n")
print(classification_report(y_test, pred))

joblib.dump(model, "production_inputs/csv_results/foot_model.pkl")

print("\nSaved model -> production_inputs/csv_results/foot_model.pkl")
