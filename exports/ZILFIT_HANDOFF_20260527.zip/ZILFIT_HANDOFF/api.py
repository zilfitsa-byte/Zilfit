from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
import joblib

app = FastAPI(title="Foot AI API")

model = joblib.load("production_inputs/csv_results/foot_model.pkl")

class FootInput(BaseModel):
    vertices: float
    foot_length_mm: float
    foot_width_mm: float
    forefoot_width_mm: float
    arch_height_geometric_mm: float
    alignment_offset_deg: float
    arch_contact_ratio: float

@app.get("/")
def root():
    return {"status": "running"}

@app.post("/predict")
def predict(data: FootInput):
    df = pd.DataFrame([data.model_dump()])
    pred = model.predict(df)[0]
    probs = model.predict_proba(df)[0]
    return {
        "prediction": pred,
        "confidence": round(float(max(probs)), 4),
        "probabilities": {
            c: round(float(p), 4)
            for c, p in zip(model.classes_, probs)
        }
    }
